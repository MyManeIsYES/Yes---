﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _23пр7ПТПМ
{
    public partial class Form1 : Form
    {
        int t = 0, num1 = 0, num2 =0, num3 = 0,moneyBase=0, money = 0;
        string[] mas = { "1.bmp", "1(1).bmp", "1(2).bmp", "1(3).bmp", "1(4).bmp", "1(5).bmp", "1(6).bmp", "1(7).bmp", "1(8).bmp"};
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            pictureBox1.Image = Image.FromFile("класс.jpg");
            button2.Enabled = false;
            pictureBox2.Image = Image.FromFile(mas[0]);
            pictureBox3.Image = Image.FromFile(mas[0]);
            pictureBox4.Image = Image.FromFile(mas[0]);
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            button2.Enabled = true;
            
            try
            {
                label6.Text = "";
                moneyBase= Convert.ToInt32(textBox1.Text);
                money = Convert.ToInt32(textBox2.Text);
                
                if (moneyBase < 9||moneyBase<money)
                {
                    label6.Text = "no money?";
                    pictureBox1.Image = Image.FromFile("no money.jpg");
                }
                else
                if (money<9||money>100)
                {
                    label6.Text = "no";
                    pictureBox1.Image = Image.FromFile("no.png");
                }
                else
                {
                    timer1.Start();
                    
                    
                    
                }
            }
            catch
            {
                pictureBox1.Image = Image.FromFile("error.bmp");
                label6.Text = "error";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            button2.Enabled = false;
            label6.Text = "";
            pictureBox1.Image = Image.FromFile("класс.jpg");
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            t++;
            Random r = new Random();
            pictureBox2.Image = Image.FromFile(mas[r.Next(1, 9)]);
            pictureBox3.Image = Image.FromFile(mas[r.Next(1, 9)]);
            pictureBox4.Image = Image.FromFile(mas[r.Next(1, 9)]);
            if (t >= 25) { timer1.Stop(); 
                t = 0; 
                num1 = r.Next(1, 9); 
                num2 = r.Next(1, 9); 
                num3 = r.Next(1, 9);
                pictureBox2.Image = Image.FromFile(mas[num1]);
                pictureBox3.Image = Image.FromFile(mas[num2]);
                pictureBox4.Image = Image.FromFile(mas[num3]);
                if (num1 != 7 && num2 != 7 && num3 != 7) money *= -1;
                else
                {
                    if (num1 == 7 && num2 == 7 && num3 == 7) { money *= 4; label6.Text = $"!!!ВЫЙГРЫШ!!!\n+{money}"; }
                    else
                    if ((num1 == 7 && num2 == 7) || (num2 == 7 && num3 == 7) || (num3 == 7 && num1 == 7)) { money *= 2; label6.Text = $"!выйгрыш!\n+{money}"; }
                    else
                    if (num1 == 7 || num2 == 7 || num3 == 7) { money *= 1; label6.Text = $"выйгрыш\n+{money}"; }
                }
                textBox1.Text = (Convert.ToInt32(textBox1.Text) + money) < 0 ? 0.ToString() : (Convert.ToInt32(textBox1.Text) + money).ToString();
                
                if (moneyBase <= 10) { pictureBox1.Image = Image.FromFile("02 (1).jpg"); }
                if (moneyBase <= 100 && moneyBase > 10) { pictureBox1.Image = Image.FromFile("01 (1).jpg"); }
                if (moneyBase > 100) { pictureBox1.Image = Image.FromFile("money.jpg"); }
                if (money < 0) { pictureBox1.Image=Image.FromFile("02 (1).jpg"); label6.Text = $"проигрыш\n{money}"; }
            }
        }
    }
}
