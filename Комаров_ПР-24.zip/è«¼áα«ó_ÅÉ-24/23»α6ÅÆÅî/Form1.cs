﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _23пр6ПТПМ
{
    public partial class Form1 : Form
    {

        PictureBox car = new PictureBox();
        int t = 0, f = 10;
        double v0=0,g=0,vb=0;
        Graphics gr;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            car.Location = new Point(20,300);
            car.Image = Image.FromFile("Без названия.jpg");
            car.SizeMode = PictureBoxSizeMode.Zoom;
            this.Controls.Add(car);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            t++;
            if (t>=0 && t<=3)
            {
                timer2.Stop();
                panel2.BackColor = Color.White;
                panel3.BackColor = Color.White;
                panel1.BackColor = Color.Red;
            }
            if (t >= 3 && t <= 6)
            {
                panel1.BackColor = Color.White;
                panel3.BackColor = Color.White;
                panel2.BackColor = Color.Yellow;
            }
            if (t >= 6 && t <= 9)
            {
                timer2.Start();
                panel1.BackColor = Color.White;
                panel2.BackColor = Color.White;
                panel3.BackColor = Color.Green;
            }
            if (t < 0 || t >= 9)
            {
                t = 0;
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Stop();
            timer2.Stop();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            timer1.Start();
            timer2.Start();
        }
        private void timer2_Tick(object sender, EventArgs e)
        {
            car.Left += f;
            if (car.Left >= Width - 100)
            {
                car.Left = 10;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            timer3.Stop();
            panel5.Top = 270;
            panel5.Left = 0;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            panel5.Top -=Convert.ToInt32(v0);
            panel5.Left += Convert.ToInt32(vb);
            if (panel5.Top >= 270)
            {
                panel5.Top = 270;
                v0 *= -1;
            }
            if (!(panel5.Left >= 0 && panel5.Left <= 270))
            {
                vb *= -1;
            }
            v0 = v0 - g;

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        

        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }

        

        private void button3_Click(object sender, EventArgs e)
        {
            
            try
            {
                timer3.Start();
                v0 = Convert.ToDouble(textBox1.Text);
                g = Convert.ToDouble(textBox3.Text);
                vb = Convert.ToDouble(textBox2.Text);
                label2.Text = "";
            }
            catch
            {
                label2.Text = "error";
            }
        }

        

        private void button5_Click(object sender, EventArgs e)
        {
            timer4.Start();
        }
        int s1=5, s2 = 5;
        private void timer4_Tick(object sender, EventArgs e)
        {
            panel7.Left+=s1;
            panel8.Left-=s2;
            if (panel7.Left<=0 || panel7.Left >= 120)
            {
                
                s1 *= -1;
            }
            if (panel8.Left >= 120 || panel8.Left <= 0)
            {

                s2 *= -1;
            }
            if (panel7.Left+20>=panel8.Left|| panel8.Left<= panel7.Left + 20)
            {

                s2 *= -1;
                s1 *= -1;
            }
        }
        private void panel7_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel8_Paint(object sender, PaintEventArgs e)
        {

        }
        private void button6_Click(object sender, EventArgs e)
        {
            timer4.Stop();
        }
    }
}
