﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace _23пр3ПТПМ
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int n1 = comboBox1.SelectedIndex;
            switch (n1)
            {
                case 0: label1.ForeColor = Color.Blue; break;
                case 1: label1.ForeColor = Color.Black; break;
                case 2: label1.ForeColor = Color.Red; break;
                case 3: label1.ForeColor = Color.Yellow; break;
                case 4: label1.ForeColor = Color.Green; break;
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int n1 = listBox1.SelectedIndex;
            switch (n1)
            {
                case 0: label1.BackColor = Color.Black; break;
                case 1: label1.BackColor = Color.Blue; break;
                case 2: label1.BackColor = Color.Red; break;
                case 3: label1.BackColor = Color.White; break;
                case 4: label1.BackColor = Color.Yellow; break;

            }
        }

        //

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            int n1 = comboBox2.SelectedIndex;
            switch (n1)
            {
                case 0: pictureBox1.Image = Image.FromFile(@"C:\Users\325L-11\Desktop\Комаров_ПР-24\23пр3ПТПМ\весна.png"); break;
                case 1: pictureBox1.Image = Image.FromFile(@"C:\Users\325L-11\Desktop\Комаров_ПР-24\23пр3ПТПМ\зима.jpg"); break;
                case 2: pictureBox1.Image = Image.FromFile(@"C:\Users\325L-11\Desktop\Комаров_ПР-24\23пр3ПТПМ\лето.jpg"); break;
                case 3: pictureBox1.Image = Image.FromFile(@"C:\Users\325L-11\Desktop\Комаров_ПР-24\23пр3ПТПМ\осень.jpg"); break;
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        //

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (textBox1.Text != "")
                {
                    int n = Convert.ToInt32(textBox1.Text) % 10;
                    n *= n;
                    label2.Text = n.ToString();
                }
                else label2.Text = "ошибка: нет числа";
                
            }
            catch
            {
                label2.Text = "ошибка: текст";
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        //
        private enum Радуга {красный, оранжевый, желтый, зеленый, голубой, синий, фиолетовый}
        private void Form1_Load(object sender, EventArgs e)
        {
            
            for (int i = 1; i <= 100; i++)
            {
                if (i % 10 == 0)
                {
                    listBox2.Items.Add(i.ToString());
                }
                
            }

        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int  s = 0, k2 = 0;
            for (int i=0; i<listBox2.Items.Count;i++)
            {
                s += Convert.ToInt32(listBox2.Items[i]);
                if (Convert.ToInt32(listBox2.Items[i]) % 2==0)
                {
                    k2++;
                }

            }
            label3.Text = $"Количество чисел:{listBox2.Items.Count}\nСумму:{s}\nКоличество нечетных:{k2}\nКоличество четных:{listBox2.Items.Count-k2}";

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
        //

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBox3.SelectedIndex)
            {
                case 0:label4.Text = "Стойте!"; label4.BackColor = Color.Red; break;
                case 1: label4.Text = "Ждите!"; label4.BackColor = Color.Yellow; break;
                case 2: label4.Text = "Идите!"; label4.BackColor = Color.Green; break;
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        //

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            Радуга signal=(Радуга)comboBox4.SelectedItem;
            switch (signal)
            {
                case Радуга.красный: label5.Text = "красное"; label5.BackColor = Color.Red; break;
                case Радуга.оранжевый: label5.Text = "оранжевый"; label5.BackColor = Color.Orange; break;
                case Радуга.голубой: label5.Text = "голубой"; label5.BackColor = Color.LightBlue; break;
                case Радуга.желтый: label5.Text = "желтый"; label5.BackColor = Color.Yellow; break;
                case Радуга.зеленый: label5.Text = "зеленый"; label5.BackColor = Color.Green; break;
                case Радуга.синий: label5.Text = "синий"; label5.BackColor = Color.Blue; break;
                case Радуга.фиолетовый: label5.Text = "фиолетовый"; label5.BackColor = Color.Violet; break;
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
        //
        private void comboBox5_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox6_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            int n = comboBox5.SelectedIndex + comboBox6.SelectedIndex;
            switch (n%4)
            {
                case 0:label6.Text = "север"; break;
                case 1: label6.Text = "запад"; break;
                case 2: label6.Text = "юг"; break;
                case 3: label6.Text = "восток"; break;
            }
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
        //

    }
}
