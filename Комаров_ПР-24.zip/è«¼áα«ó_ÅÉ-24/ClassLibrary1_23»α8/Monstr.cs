﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _23пр8
{
    public class Monstr
    {
        static Random random=new Random();
        static string[] haract = {"Добрый","Славный","Кусачий","Злой","Бешеный" };
        static string[] names = { "Гоблин", "Рыцарь", "Злыдень", "Водяной", "Воин" };
        public string? name="";
        int? hp;
        int? damage;
        public void Create_name()
        {
            switch (random.Next(11))
            {
                case 10:
                    name = "Забытая Жизнь";
                    hp = 100;
                    damage = 50;
                    break;
                case 1:
                    name = "Аномалия";
                    hp = random.Next(100,1000);
                    damage = random.Next(100, 1000); ;
                    break;
                default:
                    name = haract[random.Next(0, haract.Length)] + " " + names[random.Next(0, names.Length)];
                    break;
            }
        }
        public int? Get_hp()
        {
            return hp;
        }
        public void Set_hp(int new_hp)
        {
            hp = new_hp;
        }

        public void Set_hp(int min_hp, int max_hp)
        {
            if (!(name == "Забытая Жизнь" || name == "Аномалия"))
            {
                hp = random.Next(min_hp, max_hp + 1);
            }
        }
        
        public void Set_hp_dmg(int? dmg)
        {
            hp -= dmg;
        }

        public int? Get_damage()
        {
            return damage;
        }
        public void Set_damage(int min_damage, int max_damage)
        {
            if (!(name == "Забытая Жизнь" || name == "Аномалия"))
            {
                damage = random.Next(min_damage, max_damage + 1);
            }
        }



        public void Create_Monstr(int min_hp, int max_hp, int min_damage, int max_damage)
        {
            Create_name();
            Set_damage(min_damage,max_damage+1);
            Set_hp(min_hp, max_hp + 1);
        }
        public void Get_Monstr()
        {
            Console.WriteLine($"| Монстр: {name}\n| Здроровье: {hp}\n| Урон: {damage}");
            if (name == "Аномалия" && damage > 200 && hp > 200)
            {
                Console.WriteLine("| >>>>>БЕГИТЕ<<<<<");
            }
        }
    }
}
