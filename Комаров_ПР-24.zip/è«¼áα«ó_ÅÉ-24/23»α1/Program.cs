﻿using System.IO;
using System.Linq;
using System.Text;

namespace _23пр1
{
    internal class Program
    {
        static void WriteInConsoleFile(string nameFile)
        {
            Console.WriteLine();
            StreamReader flowRead1 = File.OpenText(nameFile);
            Console.WriteLine(flowRead1.ReadToEnd());
            flowRead1.Close();
        }
        static void ReadFail(out string nameFile)
        {
            do
            {
                Console.WriteLine("введите имя (или путь)  для текстового файла:");
                nameFile = Console.ReadLine();
                if (File.Exists(nameFile)) WriteInConsoleFile(nameFile);
                else Console.WriteLine("нет файла");
            }
            while (!File.Exists(nameFile));
        }
        static void WriteFail(in string nameFile)
        {
            string str, strNew;
            StreamReader flowRead1 = File.OpenText(nameFile);
            str = flowRead1.ReadToEnd();
            flowRead1.Close();


            var mas = str.Replace("...", "$|").Replace(".", ".|").Replace("!", "!|").Replace("?", "?|").Split('|');
            for (int i = 0; i < mas.Length; i++)
            {
                switch (mas[i][mas[i].Length-1])
                {
                    case '$':
                        mas[i] = mas[i].Remove(mas[i].Length - 1);
                        mas[i] = F1(mas[i]);
                        mas[i] += "$";
                        break;
                    case '!':
                        mas[i] = mas[i].Remove(mas[i].Length - 1);
                        mas[i] = F1(mas[i]);
                        mas[i] += '!';
                        break;
                    case '.':
                        mas[i] = mas[i].Remove(mas[i].Length - 1);
                        mas[i] = F1(mas[i]);
                        mas[i] += '.';
                        break;
                    case '?':
                        mas[i] = mas[i].Remove(mas[i].Length - 1);
                        mas[i] = F1(mas[i]);
                        mas[i] += '?';
                        break;

                }
            }
                

                StreamWriter flowWrite1 = File.CreateText("failnew1.txt");
                foreach (var el in mas)
                    flowWrite1.Write(el.Replace("$","..."));
                flowWrite1.Close();
                WriteInConsoleFile("failnew1.txt");
        }
        

        static string F1(string str)
        {
            string[] masPunctuationMarks = { " ", ",", ":", ";", "(", ")", "«", "»", "-", "\n" };
            for (int i = 0; i < masPunctuationMarks.Length; i++)
            {
                str = str.Replace(masPunctuationMarks[i], masPunctuationMarks[i] + "|");
            }
                
            var mas = str.Split('|', StringSplitOptions.RemoveEmptyEntries);
            for (int i = 0; i < mas.Length; i++)
            {
                if (
                !(mas[i] == "," ||
                mas[i] == ":" ||
                mas[i] == ";" ||
                mas[i] == "(" ||
                mas[i] == ")" ||
                mas[i] == "«" ||
                mas[i] == "»" ||
                mas[i] == "-" ||
                mas[i] == "\n" ||
                mas[i] == " ")
                )
                {
                    /*Console.WriteLine(mas[mas.Length - 1] + "\n");*/

                    string 
                        charOldL = mas[i].Substring(mas[i].Length - 1),
                        strOldL = mas[i].Remove(mas[i].Length - 1),

                        charOldR = mas[mas.Length - 1].Substring(mas[mas.Length - 1].Length - 1),
                        strOldR = mas[mas.Length - 1].Remove(mas[mas.Length - 1].Length - 1);

                    mas[i] = strOldR+ charOldL;
                    mas[mas.Length - 1] = strOldL+ charOldR;

                    break;
                }
            }
            str = "";
            foreach (var el in mas)
                str += el;
            return str;
        }



        /*static bool f2(char el)
        {
            if (el == ',' ||
                el == ':' ||
                el == ';' ||
                el == '(' ||
                el == ')' ||
                el == '«' ||
                el == '»' ||
                el == '-' ||
                el == '\n')
            {


            }
            return;
        }*/




        static void Main(string[] args)
        {
            //Индивидуальное задание  № 5.
            //задани 29
            /*string[] masPunctuationMarks = { "...", ".", "?", "!", " ", ",", ":", ";", ":", ";", "(", ")", "«", "»", "-", "\n" };*/
            string nameFile;
            /*string str = "123456";
            Console.WriteLine(str.Remove(str.Length - 1));
            Console.WriteLine(str.Substring(str.Length - 1));*/
            /*nameFile = "file1.txt";*/
            ReadFail(out nameFile);
            WriteFail(in nameFile);

            /*string str = " Cчитывает файл (при условии, что он существует, если файл отсутствует, то необходимо выдать соответствующее сообщение)$";
            str = str.Remove(str.Length - 1);
            str = F1(str)+'$';
            *//*switch (str[str.Length - 1])
            {
                case '$':
                    str = str;
                    
                    str += '$';
                    break;
                case '!':
                    str = str.Remove(str.Length - 1);
                    str = F1(str);
                    str += '!';
                    break;
                case '.':
                    str = str.Remove(str.Length - 1);
                    str = F1(str);
                    str += '.';
                    break;
                case '?':
                    str = str.Remove(str.Length - 1);
                    str = F1(str);
                    str += '.';
                    break;

            }*//*
            Console.WriteLine(str);*/

        }
    }
}