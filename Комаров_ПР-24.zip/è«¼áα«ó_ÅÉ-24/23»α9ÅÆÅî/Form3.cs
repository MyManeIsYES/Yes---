﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace _23пр9ПТПМ
{
    public partial class Form3 : Form
    {
        List<string> listQuestions = new List<string>();
        int i0 = 1;
        bool editor_mode = false;
        private bool check_noDoIt(string text)
        {
            bool b = false;
            if (text.Contains("Вопрос: ")) b = true;
            if (text.Contains("Картинка: ")) b = true;
            if (text.Contains("Ответ: ")) b = true;
            if (text.Contains("\r")) b = true;
            if (text.Contains("\n")) b = true;
            return b;
        }
        private string check_question()
        {
            string mes = "";
            if (textBox4.Text == "")
            {
                mes = "Нет вопроса";
            }
            else
            {
                if (check_noDoIt(textBox4.Text))
                {
                    mes = "Нельзя писать \"Вопрос: \", \"Картинка: \" или \"Ответ: \", а также перенос строки";
                }
                else
                {
                    if (textBox4.Text[textBox4.Text.Length - 1] != '?')
                    {
                        mes = "В вопросе должно в конце быть вопросителный знак";
                    }
                }

            }
            return mes;
        }
        private string check_format()
        {
            string mes = "";
            
            if (comboBox1.Text == "checkBox")
            {
                foreach (System.Windows.Forms.CheckBox el in panel1.Controls.OfType<System.Windows.Forms.CheckBox>())
                {
                    if (el.Checked == true)
                    {
                        mes = "";
                        break;
                    }
                    else
                    {
                        mes = "Надо выбрать хотя бы один CheckBox";
                    }

                }
            }
            if (comboBox1.Text == "radioButton")
            {
                foreach (System.Windows.Forms.RadioButton el in panel1.Controls.OfType<System.Windows.Forms.RadioButton>())
                {
                    if (el.Checked == true)
                    {
                        mes = "";
                        break;
                    }
                    else
                    {
                        mes = "Надо выбрать radioButton";
                    }
                }
            }
            if (comboBox1.Text != "checkBox"&& comboBox1.Text != "radioButton")
            {
                mes = "Надо выбрать формат";
            }

            return mes;
        }
        private string check_answerOptions()
        {
            string mes = "";
            int i = 0;
            foreach (System.Windows.Forms.TextBox el in panel1.Controls.OfType<System.Windows.Forms.TextBox>())
            {
                if (el.Text != "")
                {
                    i++;
                }
            }

            if (!(i >= 2))
            {
                mes = "Нужно как минимум 2 варианта ответов";
            }
            else
            {
                if (check_noDoIt(textBox10.Text) || check_noDoIt(textBox9.Text) || check_noDoIt(textBox8.Text) || check_noDoIt(textBox7.Text) || check_noDoIt(textBox6.Text))
                {
                    mes = "Нельзя писать \"Вопрос: \", \"Картинка: \" или \"Ответ: \", а также перенос строки";
                }
                else
                {
                    if (textBox10.Text.Contains(", ") || textBox9.Text.Contains(", ") || textBox8.Text.Contains(", ") || textBox7.Text.Contains(", ") || textBox6.Text.Contains(", "))
                    {
                        mes = "Нельзя в вариантах ответах писать \", \"";
                    }
                }
            }

            return mes;
        }
        private string check_picture()
        {
            string mes = "";
            if (check_noDoIt(textBox5.Text))
            {
                mes = "Нельзя писать \"Вопрос: \", \"Картинка: \" или \"Ответ: \", а также перенос строки";
            }
            else
            {
                if (!File.Exists(textBox5.Text) && textBox5.Text != "отсутствует")
                {
                    mes = "Неверно указан путь или/и название картинки\nБудет заменено \"отсутствует\"";
                }
            }
            return mes;
        }
        private void f1(int i)
        {
            try
            {
                textBox4.Enabled = false;
                textBox5.Enabled = false;
                comboBox1.Enabled = false;
                string[] masQuestion = listQuestions[i].Split(new char[] { '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);

                textBox4.Text = masQuestion[0];
                comboBox1.Text = masQuestion[masQuestion.Length - 1];
                panel1.Enabled = true;
                textBox5.Text = masQuestion[masQuestion.Length - 2].Replace("Картинка: ", null);

                int index = 1;
                foreach (System.Windows.Forms.RadioButton el in panel1.Controls.OfType<System.Windows.Forms.RadioButton>())
                {
                    el.Visible = false;
                    el.Enabled = false;
                }
                foreach (System.Windows.Forms.CheckBox el in panel1.Controls.OfType<System.Windows.Forms.CheckBox>())
                {
                    el.Visible = false;
                    el.Enabled = false;
                }

                //
                foreach (System.Windows.Forms.TextBox el in panel1.Controls.OfType<System.Windows.Forms.TextBox>())
                {
                    el.Enabled = false;
                    if (index < masQuestion.Length - 3)
                    {
                        el.Visible = true;
                        el.Text = masQuestion[index];
                    }
                    else
                    {
                        el.Text = "";
                        el.Visible = false;
                    }
                    index++;
                }
                index = 1;
                if (masQuestion[masQuestion.Length - 1].Contains("checkBox"))
                {
                    foreach (System.Windows.Forms.CheckBox el in panel1.Controls.OfType<System.Windows.Forms.CheckBox>())
                    {
                        el.Enabled = false;
                        el.Checked = false;
                        if (index < masQuestion.Length - 3)
                        {
                            el.Visible = true;
                        }
                        else
                        {
                            el.Visible = false;
                        }
                        index++;
                    }
                    if (masQuestion[masQuestion.Length - 3].Contains(textBox10.Text) && textBox10.Text != "") checkBox5.Checked = true;
                    else checkBox5.Checked = false;
                    if (masQuestion[masQuestion.Length - 3].Contains(textBox9.Text) && textBox9.Text != "") checkBox4.Checked = true;
                    else checkBox4.Checked = false;
                    if (masQuestion[masQuestion.Length - 3].Contains(textBox8.Text) && textBox8.Text != "") checkBox3.Checked = true;
                    else checkBox3.Checked = false;
                    if (masQuestion[masQuestion.Length - 3].Contains(textBox7.Text) && textBox7.Text != "") checkBox2.Checked = true;
                    else checkBox2.Checked = false;
                    if (masQuestion[masQuestion.Length - 3].Contains(textBox6.Text) && textBox6.Text != "") checkBox1.Checked = true;
                    else checkBox1.Checked = false;
                }

                if (masQuestion[masQuestion.Length - 1].Contains("radioButton"))
                {
                    foreach (System.Windows.Forms.RadioButton el in panel1.Controls.OfType<System.Windows.Forms.RadioButton>())
                    {
                        el.Enabled = false;
                        el.Checked = false;
                        if (index < masQuestion.Length - 3)
                        {
                            el.Visible = true;
                        }
                        else
                        {
                            el.Visible = false;
                        }
                        index++;
                    }
                    if (masQuestion[masQuestion.Length - 3].Contains(textBox10.Text)) radioButton5.Checked = true;
                    if (masQuestion[masQuestion.Length - 3].Contains(textBox9.Text)) radioButton4.Checked = true;
                    if (masQuestion[masQuestion.Length - 3].Contains(textBox8.Text)) radioButton3.Checked = true;
                    if (masQuestion[masQuestion.Length - 3].Contains(textBox7.Text)) radioButton2.Checked = true;
                    if (masQuestion[masQuestion.Length - 3].Contains(textBox6.Text)) radioButton1.Checked = true;
                }
            }
            catch
            {
                MessageBox.Show("Нет вопросов", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
        private void f2()
        {



        }

        private string encryption_str(string old_str)
        {
            string new_str = "";
            const int key0 = 21;
            int n0 = 0, n1 = 0, n2 = 0;
            foreach (char el in old_str)
            {
                if (n0 > key0) { n0 = 0; n1++; }
                if (n1 > key0) { n1 = 0; n2++; }
                if (n2 > key0) { n2 = 0; }
                new_str += (char)((int)el + (n0 + n1 + n2));
                n0++;
            }
            return new_str;
        }
        private string decoding_str(string old_str)
        {
            string new_str = "";
            const int key0 = 21;
            int n0 = 0, n1 = 0, n2 = 0;
            foreach (char el in old_str)
            {
                if (n0 > key0) { n0 = 0; n1++; }
                if (n1 > key0) { n1 = 0; n2++; }
                if (n2 > key0) { n2 = 0; }
                new_str += (char)((int)el - (n0 + n1 + n2));
                n0++;
            }
            return new_str;
        }
        public Form3()
        {
            InitializeComponent();
            this.Text = "Редактор теста";
            //ответы
            StreamReader flowRead1 = File.OpenText("вопросы.txt");
            string str0 = flowRead1.ReadToEnd();
            /*str0 = decoding_str(str0);*/
            flowRead1.Close();

            string[] masQuestions = str0.Split(new string[] { "Вопрос: " }, StringSplitOptions.RemoveEmptyEntries);

            /*StreamWriter flowWrite1 = File.CreateText("вопросы0.txt");
            flowWrite1.Write(encryption_str(str0));
            flowWrite1.Close();*/
            numericUpDown1.Maximum = 1;
            if (masQuestions.Length!=0)
            {
                numericUpDown1.Maximum = masQuestions.Length;
                numericUpDown1.Value = 1;
                foreach (var el in masQuestions)
                {
                    listQuestions.Add(el);
                }
                f1(i0 - 1);
                button9.Enabled = true;
            }
            else
            {
                button9.Enabled = false;
            }

            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            StreamWriter streamWriter_1 = File.CreateText("вопросы.txt");
            if (listQuestions.Count != 0)
            {
                string strEnd="";
                foreach (string el in listQuestions) 
                {
                    strEnd += "Вопрос: " + el;
                }
                streamWriter_1.Write(strEnd);
            }
            streamWriter_1.Close();
            this.DialogResult = DialogResult.OK;
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            panel1.Enabled = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (listQuestions.Count != 0)
            {
                if (i0 > 1)
                {
                    i0--;

                }
                else
                {
                    i0 = listQuestions.Count;
                }
                numericUpDown1.Value = i0;
                f1(i0 - 1);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (listQuestions.Count != 0)
            {
                if (i0 < listQuestions.Count)
                {
                    i0++;
                }
                else
                {
                    i0 = 1;
                }
                numericUpDown1.Value = i0;
                f1(i0 - 1);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            button10.Visible = true;
            button6.Visible = true;
            button7.Visible = true;
            button5.Enabled = false;
            button4.Enabled = false;
            button1.Enabled = false;
            button9.Enabled = false;
            numericUpDown1.Enabled = false;
            button2.Enabled = false;
            button3.Enabled = false;
            button8.Enabled = false;


            textBox4.Enabled = true;
            textBox5.Enabled = true;
            textBox5.Text = "отсутствует";
            comboBox1.Enabled = true;
            textBox4.Text = "";
            comboBox1.TabIndex = 0;
            panel1.Enabled = false;
            foreach (System.Windows.Forms.TextBox el in panel1.Controls.OfType<System.Windows.Forms.TextBox>())
            {
                el.Visible = true;
                el.Enabled = false;
                el.Text = "";
            }
            textBox10.Enabled = true;
            textBox9.Enabled = false;
            
            foreach (System.Windows.Forms.RadioButton el in panel1.Controls.OfType<System.Windows.Forms.RadioButton>())
            {
                el.Visible = true;
                el.Enabled = false;
            }
            foreach (System.Windows.Forms.CheckBox el in panel1.Controls.OfType<System.Windows.Forms.CheckBox>())
            {
                el.Visible = false;
                el.Enabled = false;
            }
            radioButton5.Checked = true;
            radioButton5.Enabled = true;
            radioButton4.Enabled = false;
            checkBox5.Checked = true;
            checkBox5.Enabled = true;
            checkBox4.Enabled = false;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            string
            message1 = check_question(),
            message2 = check_format(),
            message3 = check_answerOptions(),
            message4 = check_picture();
            if (message1 == "" && message2 == "" && message3 == "" && message4=="")
            {
                MessageBox.Show("вопрос сохранен", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                string str1 = $"{textBox4.Text}\n";
                foreach (System.Windows.Forms.TextBox el in panel1.Controls.OfType<System.Windows.Forms.TextBox>())
                {
                    if (el.Text!="")
                    {
                        str1 += $"{el.Text}\n";
                    }
                }
                str1 += $"Ответ: ";
                if (comboBox1.Text == "radioButton")
                {
                    if (radioButton5.Checked == true) str1 += textBox10.Text;
                    if (radioButton4.Checked == true) str1 +=  textBox9.Text;
                    if (radioButton3.Checked == true) str1 +=  textBox8.Text;
                    if (radioButton2.Checked == true) str1 +=  textBox7.Text;
                    if (radioButton1.Checked == true) str1 +=  textBox6.Text;

                }
                if (comboBox1.Text == "checkBox")
                {
                    string[] masstr = new string[5];
                    int i0 = 0;
                    if (checkBox5.Checked == true) { masstr[i0] = textBox10.Text; i0++; }
                    if (checkBox4.Checked == true) { masstr[i0] = textBox9.Text; i0++; }
                    if (checkBox3.Checked == true) { masstr[i0] = textBox8.Text; i0++; }
                    if (checkBox2.Checked == true) { masstr[i0] = textBox7.Text; i0++; }
                    if (checkBox1.Checked == true) { masstr[i0] = textBox6.Text; i0++; }
                    str1 += masstr[0];
                    for (i0=1;i0<masstr.Length-1;i0++)
                    {
                        if (masstr[i0]!=null)
                        {
                            str1 += ", " + masstr[i0];
                        }
                        else
                        {
                            break;
                        }
                    }
                }
                if (textBox5.Text != "отсутствует")
                {
                    str1 += $"\nКартинка: {textBox5.Text.Substring(textBox5.Text.LastIndexOf('\\')+1)}\n";
                }
                str1 += comboBox1.Text;

                
                if (editor_mode)
                {
                    if(listQuestions.Count!=0)
                    listQuestions[i0-1] = str1;
                    f1(i0 - 1);
                }
                else
                {
                    listQuestions.Add(str1);
                    numericUpDown1.Maximum = listQuestions.Count;
                    numericUpDown1.Value = listQuestions.Count;
                    f1(listQuestions.Count - 1);
                }
                



                panel1.Enabled = false;
                textBox4.Enabled = false;
                textBox5.Enabled = false;
                comboBox1.Enabled = false;

                button10.Visible = false;
                button6.Visible = false;
                button7.Visible = false;
                button5.Enabled = true;
                button4.Enabled = true;
                button1.Enabled = true;
                button9.Enabled = true;
                numericUpDown1.Enabled = true;
                button2.Enabled = true;
                button3.Enabled = true;
                button8.Enabled = true;
            }
            else
            {
                if (message1 != "") MessageBox.Show(message1, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                else
                if (message2 != "") MessageBox.Show(message2, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                else
                if (message3 != "") MessageBox.Show(message3, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                else
                if (message4 != "") MessageBox.Show(message4, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox5.Text = "отсутствует";
            }


            
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (listQuestions.Count != 0)
                f1(i0-1);
            button10.Visible = false;
            button6.Visible = false;
            button7.Visible = false;
            button5.Enabled = true;
            button4.Enabled = true;
            button1.Enabled = true;
            button9.Enabled = true;
            numericUpDown1.Enabled = true;
            button2.Enabled = true;
            button3.Enabled = true;
            button8.Enabled = true;
        }
        private void button9_Click(object sender, EventArgs e)
        {
            editor_mode = true;

            button10.Visible = true;
            button6.Visible = true;
            button7.Visible = true;
            button5.Enabled = false;
            button4.Enabled = false;
            button1.Enabled = false;
            button9.Enabled = false;
            numericUpDown1.Enabled = false;
            button2.Enabled = false;
            button3.Enabled = false;
            button8.Enabled = false;

            textBox4.Enabled = true;
            textBox5.Enabled = true;
            comboBox1.Enabled = true;

            

            foreach (System.Windows.Forms.TextBox el in panel1.Controls.OfType<System.Windows.Forms.TextBox>())
            {
                el.Visible = true;
                if (el.Text!="")
                {
                    el.Enabled = true;
                }
                else
                {
                    el.Enabled = true;
                    break;
                }
            }
            

            if (comboBox1.Text == "checkBox")
            {
                foreach (System.Windows.Forms.CheckBox el in panel1.Controls.OfType<System.Windows.Forms.CheckBox>())
                {
                    el.Visible = true;
                    el.Enabled = false;
                }
                if (textBox10.Enabled == true && textBox10.Text!="") { checkBox5.Enabled = true; }
                if (textBox9.Enabled == true && textBox9.Text != "") { checkBox4.Enabled = true; }
                if (textBox8.Enabled == true && textBox8.Text != "") { checkBox3.Enabled = true; }
                if (textBox7.Enabled == true && textBox7.Text != "") { checkBox2.Enabled = true; }
                if (textBox6.Enabled == true && textBox6.Text != "") { checkBox1.Enabled = true; }
                /*if (masQuestion[masQuestion.Length - 3].Contains(textBox10.Text)) checkBox5.Checked = true;
                if (masQuestion[masQuestion.Length - 3].Contains(textBox9.Text)) checkBox4.Checked = true;
                if (masQuestion[masQuestion.Length - 3].Contains(textBox8.Text)) checkBox3.Checked = true;
                if (masQuestion[masQuestion.Length - 3].Contains(textBox7.Text)) checkBox2.Checked = true;
                if (masQuestion[masQuestion.Length - 3].Contains(textBox6.Text)) checkBox1.Checked = true;*/
            }
            if (comboBox1.Text == "radioButton")
            {
                foreach (System.Windows.Forms.RadioButton el in panel1.Controls.OfType<System.Windows.Forms.RadioButton>())
                {
                    el.Visible = true;
                    el.Enabled = false;
                }
                if (textBox10.Enabled == true) { radioButton5.Enabled = true; }
                if (textBox9.Enabled == true) { radioButton4.Enabled = true; }
                if (textBox8.Enabled == true) { radioButton3.Enabled = true; }
                if (textBox7.Enabled == true) { radioButton2.Enabled = true; }
                if (textBox6.Enabled == true) { radioButton1.Enabled = true; }
                /*if (masQuestion[masQuestion.Length - 3].Contains(textBox10.Text)) radioButton5.Checked = true;
                if (masQuestion[masQuestion.Length - 3].Contains(textBox9.Text)) radioButton4.Checked = true;
                if (masQuestion[masQuestion.Length - 3].Contains(textBox8.Text)) radioButton3.Checked = true;
                if (masQuestion[masQuestion.Length - 3].Contains(textBox7.Text)) radioButton2.Checked = true;
                if (masQuestion[masQuestion.Length - 3].Contains(textBox6.Text)) radioButton1.Checked = true;*/
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (listQuestions.Count != 0)
            {
                listQuestions.RemoveAt(i0 - 1);
                f1(i0-1);
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (listQuestions.Count != 0)
            {
                i0 = (int)numericUpDown1.Value;
                f1(i0 - 1);
            }
            
        }
        
        
        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            bool B=true;
            if (comboBox1.Text== "checkBox")
            {
                B = false;
            }
            if (comboBox1.Text == "radioButton")
            {
                B = true;
            }
            foreach (System.Windows.Forms.RadioButton el in panel1.Controls.OfType<System.Windows.Forms.RadioButton>())
            {
                el.Visible = B;
            }
            foreach (System.Windows.Forms.CheckBox el in panel1.Controls.OfType<System.Windows.Forms.CheckBox>())
            {
                el.Visible = !B;
            }
        }
        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            if (textBox6.Text != "")
            {
                radioButton1.Enabled = true;
                checkBox1.Enabled = true;
            }
            else
            {
                checkBox1.Checked = false;
                radioButton1.Checked = false;
                radioButton1.Enabled = false;
                checkBox1.Enabled = false;
            }
        }
        private void textBox7_TextChanged(object sender, EventArgs e)
        {
            textBox6.Enabled = true;
            if (textBox7.Text != "")
            {
                radioButton2.Enabled = true;
                checkBox2.Enabled = true;
            }
            else
            {
                checkBox2.Checked = false;
                radioButton2.Checked = false;
                radioButton2.Enabled = false;
                checkBox2.Enabled = false;
            }
            /*radioButton1.Enabled = true;
            checkBox1.Enabled = true;*/
        }
        private void textBox8_TextChanged(object sender, EventArgs e)
        {
            textBox7.Enabled = true;
            if (textBox8.Text != "")
            {
                radioButton3.Enabled = true;
                checkBox3.Enabled = true;
            }
            else
            {
                checkBox3.Checked = false;
                radioButton3.Checked = false;
                radioButton3.Enabled = false;
                checkBox3.Enabled = false;
            }
            /*radioButton2.Enabled = true;
            checkBox2.Enabled = true;*/
        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {
            textBox8.Enabled = true;
            if (textBox9.Text != "")
            {
                radioButton4.Enabled = true;
                checkBox4.Enabled = true;
            }
            else
            {
                checkBox4.Checked = false;
                radioButton4.Checked = false;
                radioButton4.Enabled = false;
                checkBox4.Enabled = false;
            }
            /*radioButton3.Enabled = true;
            checkBox3.Enabled = true;*/

        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {
            textBox9.Enabled = true;
            if (textBox10.Text != "")
            {
                radioButton5.Enabled = true;
                checkBox5.Enabled = true;
            }
            else
            {
                checkBox5.Checked = false;
                radioButton5.Checked = false;
                radioButton5.Enabled = false;
                checkBox5.Enabled = false;
            }
            /*radioButton4.Enabled = true;
            checkBox4.Enabled = true;*/
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            if (File.Exists(textBox5.Text))
            {
                pictureBox1.Image = System.Drawing.Image.FromFile(textBox5.Text);
            }
            else
            {
                pictureBox1.Image =null;
            }
        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog=new OpenFileDialog();
            openFileDialog.InitialDirectory = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),"Downloads");
            openFileDialog.Title = "Выберите картинку";
            if (openFileDialog.ShowDialog()==DialogResult.OK)
            {
                var file=openFileDialog.FileName;
                File.Copy(Path.Combine(Path.GetDirectoryName(file), Path.GetFileName(file)), Path.GetFileName(file), true);
                textBox5.Text = file;
            }
        }
    }
}
