﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace _23пр9ПТПМ
{

    public partial class Form1 : Form
    {
        Form2 form2=new Form2();
        string[] masQuestions, masQuestion;
        int[] masNum;
        int curr_numb = 0, answer = 0, index = 1, scores=0;
        string str;

        private void Form1_Load(object sender, EventArgs e)
        {
            form2.ShowDialog();
            str = form2.Get_str();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //
            if (masQuestion[masQuestion.Length - 1].Contains("radioButton"))
            {
                answer++;
                index = 1;
                foreach (System.Windows.Forms.RadioButton el in groupBox1.Controls.OfType<System.Windows.Forms.RadioButton>())
                {
                    if (el.Checked && masQuestion[masQuestion.Length - 3].Contains(el.Text))
                    { scores++; break; }
                    index++;
                    if (index >= masQuestion.Length - 3) break;
                }
            }
            //
            if (masQuestion[masQuestion.Length - 1].Contains("checkBox"))
            {
                int y=0;
                index = 1;
                foreach (System.Windows.Forms.CheckBox el in groupBox1.Controls.OfType<System.Windows.Forms.CheckBox>())
                {

                    var mas = masQuestion[masQuestion.Length - 3].Replace("Ответ: ", null).Split(new string[] { ", ","\n","\r" },StringSplitOptions.RemoveEmptyEntries);
                    y = mas.Length;
                    /*label1.Text = 'b' + mas[0].Remove(mas[0].Length - 1) + 'd' + '\n' + 'b' + el.Text.Remove(el.Text.Length - 1) + 'd';*/

                    /*int i = 0;*/
                    if (el.Checked)
                        foreach (var el1 in mas)
                        {
                            if(el1.Remove(el1.Length - 1) == (el.Text.Remove(el.Text.Length - 1))) scores++;
                        }
                    index++;
                    /*if (i==mas.Length-1) { scores++; }*/
                    if(index >= masQuestion.Length - 3 ) break;
                }
                answer += y;
            }
            //

            foreach (System.Windows.Forms.RadioButton el in groupBox1.Controls.OfType<System.Windows.Forms.RadioButton>())
                el.Visible = false;
            foreach (System.Windows.Forms.CheckBox el in groupBox1.Controls.OfType<System.Windows.Forms.CheckBox>())
                el.Visible = false;

            if (curr_numb < masQuestions.Length-1)
            {
                curr_numb++;
                Get_question();
            }
            else
            {
                button1.Enabled = false;
                StreamWriter streamWriter1 = File.AppendText("результаты.txt");
                streamWriter1.WriteLine(str+"\nРезультат: "+scores+" из "+answer+" баллов");
                streamWriter1.Close();
                MessageBox.Show($"Из {answer} верны {scores}", "Результаты");
            }
            

            
        }
        ////
        public Form1()
        {
            InitializeComponent();
            foreach (System.Windows.Forms.RadioButton el in groupBox1.Controls.OfType<System.Windows.Forms.RadioButton>())
                el.Visible = false;
            foreach (System.Windows.Forms.CheckBox el in groupBox1.Controls.OfType<System.Windows.Forms.CheckBox>())
                el.Visible = false;
            //
            /*StreamReader flowRead1 = File.OpenText("вопросы0.txt");
            string str0 = flowRead1.ReadToEnd();
            str0 = decoding_str(str0);
            flowRead1.Close();*/
            //
            StreamReader flowRead1 = File.OpenText("вопросы.txt");
            string str0 = flowRead1.ReadToEnd();
            flowRead1.Close();
            //
            masQuestions = str0.Split(new string[] { "Вопрос: " }, StringSplitOptions.RemoveEmptyEntries);
            //
            /*label1.Text = masQuestions[0] + "ds";*/
            //
            Random random = new Random();
            masNum = new int[masQuestions.Length];
            for (int i = 0; i < masNum.Length; i++)
                masNum[i] = -1;
            int m = 0;
            while (m!=masNum.Length)
            {
                int r = random.Next(0,masNum.Length);
                if (!masNum.Contains(r))
                {
                    masNum[m] = r;
                    m++;
                }
            }

            /*for (int i1=0;i1<20;i1++)
            {
                
                int x1= random.Next(0, masQuestions.Length), x2= random.Next(0, masQuestions.Length);
                string str = masQuestions[x1];
                masQuestions[x1] = masQuestions[x2];
                masQuestions[x2] = str;
            }*/
            //
            /*label1.Text = 'b' + masQuestion[masQuestion.Length - 1].Replace("Ответ: ", null) + 'd';*/

           
            Get_question();
            
        }
        ////
        private void Get_question()
        {
            try
            {
                this.Text = "Вопрос " + (curr_numb + 1);
                masQuestion = masQuestions[masNum[curr_numb]].Split(new char[] { '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);
                //
                groupBox1.Text = masQuestion[0];
                //
                if (!masQuestion[masQuestion.Length - 2].Contains("отсутствует"))
                    pictureBox1.Image = Image.FromFile(masQuestion[masQuestion.Length - 2].Replace("Картинка: ", null));
                else pictureBox1.Image = null;
                //
                if (masQuestion[masQuestion.Length - 1].Contains("radioButton"))
                {
                    index = 1;
                    foreach (System.Windows.Forms.RadioButton el in groupBox1.Controls.OfType<System.Windows.Forms.RadioButton>())
                    {
                        el.Visible = true;
                        el.Text = masQuestion[index];
                        index++;
                        if (index >= masQuestion.Length - 3) break;
                    }
                }
                //
                if (masQuestion[masQuestion.Length - 1].Contains("checkBox"))
                {
                    index = 1;
                    foreach (System.Windows.Forms.CheckBox el in groupBox1.Controls.OfType<System.Windows.Forms.CheckBox>())
                    {
                        el.Visible = true;
                        el.Text = masQuestion[index];
                        index++;
                        if (index >= masQuestion.Length - 3) break;
                    }
                }
            }
            catch
            {
                MessageBox.Show("Нет вопросов", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
        private string decoding_str(string old_str)
        {
            string new_str = "";
            const int key0 = 21;
            int n0 = 0, n1 = 0, n2 = 0;
            foreach (char el in old_str)
            {
                if (n0 > key0) { n0 = 0; n1++; }
                if (n1 > key0) { n1 = 0; n2++; }
                if (n2 > key0) { n2 = 0; }
                new_str += (char)((int)el - (n0 + n1 + n2));
                n0++;
            }
            return new_str;
        }

    }
}
