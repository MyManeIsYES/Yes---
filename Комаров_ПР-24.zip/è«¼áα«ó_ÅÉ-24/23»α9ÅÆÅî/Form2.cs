﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Remoting.Messaging;

namespace _23пр9ПТПМ
{
    public partial class Form2 : Form
    {
        Form3 form3=new Form3();
        public Form2()
        {
            InitializeComponent();
            this.ControlBox = false;
            this.Text ="Регистрация";
        }
        private string Check_Name(string text)
        {
            string mes = "";
            if (text == "")
                mes = "Поле имя не заполнен";
            else
                for (int i = 0; i < text.Length; i++)
                    if (!(char.IsLetter(text[i])))
                        mes = "Имя можно писать только буквы";
            return mes;
        }
        private string Check_Surname(string text)
        {
            string mes = "";
            if (text == "")
                mes = "Поле фамилия не заполнен";
            else
                for (int i = 0; i < text.Length; i++)
                    if (!(char.IsLetter(text[i])))
                        mes = "Фамилия можно писать только буквы";
            return mes;
        }
        private string Check_Group(string text)
        {
            string mes = "";
            if (text == "")
                mes = "Поле группа не заполнен";
            return mes;
        }
        public string Get_str() 
        {
            return "Имя: " + textBox1.Text + "\nФамилия: " + textBox2.Text + "\nГруппа: " + textBox3.Text;
        }
        private void button1_Click(object sender, EventArgs e)
        {
                string
            message1 = Check_Name(textBox1.Text),
            message2 = Check_Surname(textBox2.Text),
            message3 = Check_Group(textBox3.Text);
            if (message1 == "" && message2 == "" && message3 == "") 
            {
                MessageBox.Show("регистрация прошла успешно\nможете перейти к тесту", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.DialogResult = DialogResult.OK;
            } 
            else
            {
                if (message1 != "") MessageBox.Show(message1, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                else
                if (message2 != "") MessageBox.Show(message2, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                else
                if (message3 != "") MessageBox.Show(message3, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


            /*if (true)
            {
                DialogResult = DialogResult.OK;
                form1.ShowDialog();

            }
            else
            {
                MessageBox.Show("error");
            }*/
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox4.Text!="")
            {
                form3.ShowDialog();
            }
            else
            {
                MessageBox.Show("неверный пароль", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
