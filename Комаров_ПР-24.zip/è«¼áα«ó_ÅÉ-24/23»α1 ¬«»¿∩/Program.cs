﻿using System.IO;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace _23пр1
{
    internal class Program
    {
        static void WriteInConsoleFile(string nameFile)
        {
            Console.WriteLine();
            StreamReader flowRead1 = File.OpenText(nameFile);
            Console.WriteLine(flowRead1.ReadToEnd());
            flowRead1.Close();
        }
        static void ReadFail(out string nameFile)
        {
            do
            {
                Console.WriteLine("введите имя (или путь)  для текстового файла:");
                nameFile = Console.ReadLine();
                if (File.Exists(nameFile)) WriteInConsoleFile(nameFile);
                else Console.WriteLine("нет файла");
            }
            while (!File.Exists(nameFile));
        }
        static void WriteFail(in string nameFile)
        {
            StreamReader flowRead1 = File.OpenText(nameFile);
            string str = flowRead1.ReadToEnd();
            flowRead1.Close();
            
            string[] masPunctuationMarks = { "@", ".", "?", "!" };
            foreach (var el in masPunctuationMarks)
                str = str.Replace(el, el + "|");

            var masstr = str.Split('|');
            str = "";
            foreach (var el in masstr)
                str += F1(el).Replace("@", "...");

            StreamWriter flowWrite1 = File.CreateText("failnew1.txt");
            flowWrite1.Write(str);
            flowWrite1.Close();
            WriteInConsoleFile("failnew1.txt");
        }


        static string F1(string str)
        {
            string[] masPunctuationMarks = { "@", ".", "?", "!", " ", ",", ":", ";", "(", ")", "«", "»", "-", "\n", "\r" };
            for (int i = 0; i < masPunctuationMarks.Length; i++)
                str = str.Replace(masPunctuationMarks[i], "|" + masPunctuationMarks[i] + "|");
            var massubstr = str.Split('|', StringSplitOptions.RemoveEmptyEntries);



            for (int il = 0; il < massubstr.Length; il++)
                if (F2(massubstr[il]))
                {
                    for (int ir = massubstr.Length - 1; ir >= 0; ir--)
                        if (F2(massubstr[ir]))
                        {
                            string strmiddle = massubstr[il];
                            massubstr[il] = massubstr[ir];
                            massubstr[ir] = strmiddle;
                            break;
                        }
                    break;
                }
            return String.Join("", massubstr);
        }

        static bool F2(string substr)
        {
            bool b = true;
            if (
            substr == "@" ||
            substr == "." ||
            substr == "?" ||
            substr == "!" ||
            substr == " " ||
            substr == "," ||
            substr == ":" ||
            substr == ";" ||
            substr == "(" ||
            substr == ")" ||
            substr == "«" ||
            substr == "»" ||
            substr == "-" ||
            substr == "\n" ||
            substr == "\r"
            )
                b = false;
            return b;
        }




        static void Main(string[] args)
        {
            //Индивидуальное задание  № 5.
            //задани 29

            string nameFile;
            ReadFail(out nameFile);
            WriteFail(in nameFile);


        }
    }
}