﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _23пр14
{
    internal class Class1
    {
        public static long[,] operator *(int[,] mas1, int[,] mas2)
        {
            return new mas3;
        }
        public static long[,] f1(int[,] mas1, int[,] mas2)
        {
            long[,] mas3 = new long[mas1.GetLength(0), mas2.GetLength(1)];
            if (mas1.GetLength(1) == mas2.GetLength(0))
            {
                for (int i3 = 0; i3 < mas3.GetLength(0); i3++)
                    for (int j3 = 0; j3 < mas3.GetLength(1); j3++)
                        for (int k = 0; k < mas2.GetLength(0); k++)
                            mas3[i3, j3] += mas1[i3, k] * mas2[k, j3];
                return mas3;
            }
            else
            {
                Console.WriteLine("Матрицы нельзя умножить");
            }
            return mas3;
        }
        
        
    }
}
