﻿using _23пр14;
namespace _23пр14
{
    internal class Program
    {
        private static object convert;

        static void Main(string[] args)
        {
            Class1 c = new Class1();
            int w1=0, w2=0, h1=0, h2=0;

            f2(ref w1, 1, 21, 0,0,0);
            do
            {
                int x = Console.CursorLeft, y = Console.CursorTop;
                f2(ref w2, 1, 21, 1,0,0);
                f2(ref h1, 1, 21, 2,0,0);
                int x1 = Console.CursorLeft, y1 = Console.CursorTop;
                Console.WriteLine($"{null,1000}");
                Console.SetCursorPosition(x1, y1);
                if (w2 != h1) 
                {
                    Console.Write("error w2 != h1\t\n");
                    Console.SetCursorPosition(x, y);
                }
            }
            while (w2 != h1);
            f2(ref h2, 1, 21, 3,0,0);

            

            var mas1=new int[w1,h1];
            var mas2 = new int[w2,h2];


            for (int i = 0; i < mas1.GetLength(0); i++)
            {
                for (int j = 0; j < mas1.GetLength(1); j++)
                {
                    f2(ref mas1[i,j], int.MinValue,int.MaxValue,4,i,j);
                }
            }
            for (int i = 0; i < mas2.GetLength(0); i++)
            {
                for (int j = 0; j < mas2.GetLength(1); j++)
                {
                    f2(ref mas2[i, j], int.MinValue, int.MaxValue, 5, i, j);
                }
            }
           

            Console.WriteLine("mas1");
            f3(mas1);
            Console.WriteLine("mas2");
            f3(mas2);
            Console.WriteLine("mas3");
            f3(c.f1(mas1, mas2));
        }
        
        static void f2(ref int num,int min,int max,int t,int i,int j)
        {
            bool b = true;
            int x, y;
            do
            {
                x = Console.CursorLeft; y = Console.CursorTop;
                switch (t) 
                {
                    case 0:
                        Console.Write("w1 = ");
                        break;
                    case 1:
                        Console.Write("w2 = ");
                        break;
                    case 2:
                        Console.Write("h1 = ");
                        break;
                    case 3:
                        Console.Write("h2 = ");
                        break;
                    case 4:
                        Console.Write($"mas1[{i,2},{j,2}] = ");
                        break;
                    case 5:
                        Console.Write($"mas2[{i,2},{j,2}] = ");
                        break;
                }
                int x1 = Console.CursorLeft, y1 = Console.CursorTop;
                Console.Write($"{null,100}");
                Console.SetCursorPosition(x1, y1);
                try
                {
                    num = Convert.ToInt32(Console.ReadLine());
                    if (max < num)
                    {
                        Console.Write($"error max{null,100}\n");
                        Console.SetCursorPosition(x, y);
                    }
                    else
                    if (min > num)
                    {
                        Console.Write($"error min{null,100}\n");
                        Console.SetCursorPosition(x, y);
                    }
                    else
                    b = false;
                }
                catch
                {
                    Console.Write($"error no{null,100}\n");
                    Console.SetCursorPosition(x, y);
                }
            } 
            while (b);
        }
        public static void f3(long[,] mas)
        {
            for (int i = 0; i < mas.GetLength(0); i++)
            {
                for (int j = 0; j < mas.GetLength(1); j++)
                {
                    Console.Write($"{mas[i, j],10} ");
                }
                Console.WriteLine();
            }
        }
        public static void f3(int[,] mas)
        {
            for (int i = 0; i < mas.GetLength(0); i++)
            {
                for (int j = 0; j < mas.GetLength(1); j++)
                {
                    Console.Write($"{mas[i, j],10} ");
                }
                Console.WriteLine();
            }
        }
    }
}