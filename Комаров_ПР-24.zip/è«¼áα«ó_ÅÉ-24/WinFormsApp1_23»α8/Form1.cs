using _23пр8;
using System.Windows.Forms;
using System.Threading;

namespace WinFormsApp1_23пр8
{
    public partial class Form1 : Form
    {
        Monstr monstr1 = new Monstr();
        int? hp_monstr_max = 0, hp_gamer = 100, damage_gamer = 10, hp_gamer_max = 100, chance_dodge_gamer = 0;
        int t = 0,i=4, t1=0;
        Random random1 = new Random();
        string[] mas = { "m1.jpg", "m2.jpg", "m3.jpg", "m4.jpg", "m5.jpg", "m6.jpg", "m7.jpg" };
        bool b = false;
        public Form1()
        {
            InitializeComponent();
            
            pictureBox1.Image = Image.FromFile(mas[i]);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Start();
            button1.Visible = false;
            hp_gamer = hp_gamer_max;
            monstr1.Set_hp((int)hp_monstr_max);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            i--;
            if (i<0)
            {
                i = mas.Length-1;
            }
            pictureBox1.Image = Image.FromFile(mas[i]);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            groupBox1.Visible = true;
            groupBox2.Visible = false;
            groupBox3.Visible = false;
            button1.Visible = false;
            button2.Visible = true;
            button3.Visible = true;
            pictureBox2.Visible = false;
            button5.Visible = false;

            label20.Text = "";
            label20.Visible = false;
            label19.Text = "";
            label19.Visible = false;
            label18.Text = "";
            label18.Visible = false;

        }

        private void label19_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            i++;
            if (i == mas.Length)
            {
                i = 0;
            }
            pictureBox1.Image = Image.FromFile(mas[i]);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (t%70==1)
            {
                
                if (random1.Next(0, 2) == 0)
                {
                    label18.Text = "";
                    monstr1.Set_hp_dmg(damage_gamer);
                    label18.Text = "игрок попал\n";
                    if (monstr1.Get_hp() <= 0)
                    {
                        progressBar1.Value = Convert.ToInt32(0);
                        label16.Text = 0.ToString();
                    }
                    else
                    {
                        progressBar1.Value = Convert.ToInt32(monstr1.Get_hp());
                        label16.Text = monstr1.Get_hp().ToString();
                    }
                }
                else 
                {
                    label18.Text = "";
                    label18.Text = "игрок промазал\n";
                }
                if (monstr1.Get_hp() <= 0)
                {
                    button5.Visible = true;
                    label20.Visible = true;
                    t = 0;
                    label20.Text = "выграл игрок";
                    button1.Enabled = true;
                    timer1.Stop();
                }
                Thread.Sleep(1000);
                if (random1.Next(0, 2) == 0)
                {
                    label19.Text = "";
                    hp_gamer -= monstr1.Get_damage();
                    label19.Text ="монстор попал";
                    if (hp_gamer <= 0)
                    {
                        hp_gamer = 0;
                        progressBar2.Value = Convert.ToInt32(hp_gamer);
                        label17.Text = hp_gamer.ToString();
                    }
                    else
                    {
                        progressBar2.Value = Convert.ToInt32(hp_gamer);
                        label17.Text = hp_gamer.ToString();
                    }
                }
                else 
                {
                    label19.Text = "";
                    label19.Text = "монстор промазал";
                }
                if (hp_gamer <= 0)
                {
                    button5.Visible = true;
                    label20.Visible = true;
                    t = 0;
                    label20.Text = "выграл монстор";
                    button1.Enabled = true;
                    timer1.Stop();
                }
                Thread.Sleep(1000);
            }
            

            t++;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            monstr1.Create_Monstr(50,100,10,50);
            hp_monstr_max = monstr1.Get_hp();
            label4.Text = monstr1.name;
            label16.Text = monstr1.Get_hp().ToString();
            label8.Text=monstr1.Get_damage().ToString();
            label15.Text = textBox1.Text;
            switch (comboBox1.SelectedIndex)
            {
                case 0: hp_gamer = 100; break;
                case 1: hp_gamer = 200; break;
                case 2: hp_gamer = 500; break;
                case 3: hp_gamer = 1000; break;
                default: break;
            }
            switch (comboBox2.SelectedIndex)
            {
                case 0: damage_gamer = 10; break;
                case 1: damage_gamer = 20; break;
                case 2: damage_gamer = 30; break;
                case 3: damage_gamer = 100; break;
                case 4: damage_gamer = 50; break;
                default: break;
            }
            hp_gamer_max = hp_gamer;

            progressBar2.Maximum = Convert.ToInt32(hp_gamer_max);
            progressBar1.Maximum = Convert.ToInt32(hp_monstr_max);
            progressBar2.Value = Convert.ToInt32(hp_gamer_max);
            progressBar1.Value = Convert.ToInt32(hp_monstr_max);

            label18.Visible = true;
            label19.Visible = true;
            label17.Text = hp_gamer.ToString();
            label11.Text = damage_gamer.ToString();
            groupBox1.Visible = false;
            groupBox2.Visible=true;
            groupBox3.Visible = true;
            button1.Visible = true;
            button2.Visible = false;
            button3.Visible=false;
            pictureBox2.Visible = true;

            pictureBox2.Image = Image.FromFile(mas[random1.Next(0, mas.Length)]);
        }

        private void label17_Click(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }
    }
}