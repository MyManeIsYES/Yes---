﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _23пр1ПТПМ
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox1.Text != "" || textBox2.Text != "")
                {
                    double a = Convert.ToDouble(textBox1.Text), b = Convert.ToDouble(textBox2.Text);
                        label2.Text = Math.Pow(a,b).ToString();
                }
                else label2.Text = "ошибка: нет числа";
            }
            catch
            {
                label2.Text = "ошибка: текст";
            }

        }
        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox1.Text != "" || textBox2.Text != "")
                {
                    double a = Convert.ToDouble(textBox1.Text), b = Convert.ToDouble(textBox2.Text);
                    label2.Text = (a + b).ToString();
                }
                else label2.Text = "ошибка: нет числа";
            }
            catch
            {
                label2.Text = "ошибка: текст";
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox1.Text != "" || textBox2.Text != "")
                {
                    double a = Convert.ToDouble(textBox1.Text), b = Convert.ToDouble(textBox2.Text);
                    label2.Text = (a - b).ToString();
                }
                else label2.Text = "ошибка: нет числа";
            }
            catch
            {
                label2.Text = "ошибка: текст";
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox1.Text != "" || textBox2.Text != "")
                {
                    double a = Convert.ToDouble(textBox1.Text), b = Convert.ToDouble(textBox2.Text);
                    label2.Text = (a * b).ToString();
                }
                else label2.Text = "ошибка: нет числа";
            }
            catch
            {
                label2.Text = "ошибка: текст";
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox1.Text != "" || textBox2.Text != "")
                {
                    double a = Convert.ToDouble(textBox1.Text), b = Convert.ToDouble(textBox2.Text);
                    if (b != 0)
                        label2.Text = (a / b).ToString();
                    else label2.Text = "ошибка: нельзя делить на 0";
                }
                else label2.Text = "ошибка: нет числа";
            }
            catch
            {
                label2.Text = "ошибка: текст";
            }
        }
        private void label2_Click(object sender, EventArgs e)
        {

        }

        //
        
        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }
        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            
            try
            {
                if (textBox3.Text != "" || textBox4.Text != "" || textBox5.Text != "")
                {
                    double USD = Convert.ToDouble(textBox3.Text),
                        EUR = Convert.ToDouble(textBox4.Text),
                        RUB = Convert.ToDouble(textBox5.Text);
                    if (USD>=0 && EUR>=0 && RUB>=0)
                    {
                        label8.Text = (RUB / USD).ToString();
                        label9.Text = (RUB / EUR).ToString();
                    }
                    else
                    {
                        label8.Text = "ошибка: отрицательное число";
                        label9.Text = "ошибка: отрицательное число";
                    }
                }
                else
                {
                    label8.Text = "ошибка: нет числа";
                    label9.Text = "ошибка: нет числа";
                }

            }
            catch
            {
                label8.Text = "ошибка: текст";
                label9.Text = "ошибка: текст";
            }
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        //

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox6.Text != "" || textBox7.Text != "" || textBox8.Text != "" || textBox9.Text != "")
                {
                    double x1 = Convert.ToDouble(textBox6.Text),
                        y1 = Convert.ToDouble(textBox7.Text),
                        x2 = Convert.ToDouble(textBox8.Text),
                        y2 = Convert.ToDouble(textBox9.Text);
                    label12.Text = (Math.Sqrt(Math.Pow(x2-x1,2)+ Math.Pow(y2-y1,2))).ToString();
                }
                else
                {
                    label12.Text = "ошибка: нет числа";
                }

            }
            catch
            {
                label12.Text = "ошибка: текст";
            }
        }

        private void label12_Click(object sender, EventArgs e)
        {

        }
    }
}
