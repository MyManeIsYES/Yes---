﻿namespace _23пр2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //10

        }
    }
}