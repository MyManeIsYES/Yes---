using System.Windows.Forms;

namespace _23пр13
{
    public partial class Form1 : Form
    {
        List<Button> cells = new List<Button>();
        Random random = new Random();
        string[] masIcons = { "!", "N", ",", "k", "b", "v", "w", "z", "f", "d", "e" };
        List<string> icons = new List<string>();
        Panel panel = new Panel();
        public int Columns=2, Rows=2;
        TableLayoutPanel table;
        int size = 1;
        Form2 form2 = new Form2();

        private void Create_Table(int Columns, int Rows)
        {
            panel.Controls.Clear();
            table = tableLayoutPanel1; //важно:
            table.Dock = DockStyle.Fill;
            //table.BackColor = Color.CornflowerBlue;


            panel.Width = Convert.ToInt32(this.Width * 0.9f);
            panel.Height = Convert.ToInt32(this.Height * 0.9f);
            //границы
            table.CellBorderStyle = TableLayoutPanelCellBorderStyle.Inset;
            table.Location = new System.Drawing.Point(0, 0);
            table.Visible = true;
            table.ColumnCount = Convert.ToInt32(Columns);
            table.RowCount = Convert.ToInt32(Rows);

            int width = 100 / table.ColumnCount;
            int height = 100 / table.RowCount;

            //  table.Font = new Font("Webdings", 48);

            // добавляем колонки и строки
            for (int col = 0; col < table.ColumnCount; col++)
            {
                // добавляем колонку
                table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, width));

                for (int row = 0; row < table.RowCount; row++)
                {
                    // добавляем строку
                    if (col == 0)
                    {
                        table.RowStyles.Add(new RowStyle(SizeType.Percent, height));
                    }

                    if ((col + row+1)!=0) 
                    {
                        var Button = new Button();
                        Button.Dock = System.Windows.Forms.DockStyle.Fill;
                        Button.Text = (col + row).ToString();
                        cells.Add(Button);
                        table.Controls.Add(Button, col, row);
                    }
                    /*int position = Convert.ToInt32(((Button)(row+col)).Tag);*/
                    /*label.Font = new System.Drawing.Font("Webdings", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
                    label.AutoSize = true;
                    label.Font = new Font("Webdings", size);
                    label.Name = ("label" + row + col).ToString();*/

                    /*int randomNumber = random.Next(icons.Count);
                    label.Text = icons[randomNumber].ToString();
                    icons.RemoveAt(randomNumber);*/


                    /*label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;*/


                }

            }
            Controls.Add(panel);
            panel.Controls.Add(table);



        }
        private void AssignIconsToSquares()
        {
            /*foreach (Control control in tableLayoutPanel1.Controls)
            {
                Label iconLabel = control as Label;
                if (iconLabel != null)
                {
                    int randomNumber = random.Next(icons.Count);
                    iconLabel.Text = icons[randomNumber];
                    iconLabel.ForeColor = iconLabel.BackColor;
                    icons.RemoveAt(randomNumber);
                }
            }*/

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            form2.ShowDialog();
            Rows = form2.Rows;
            Columns = form2.Columns;
            Create_Table(Columns, Rows);
            AssignIconsToSquares();
        }

        public Form1()
        {
            
            InitializeComponent();

            /*size = 48;
            int t = 0;
            for (int i = 0; i < Rows * Columns; i++)
            {
                if (i % 2 == 0)
                {
                    t++;
                }
                icons.Add($"{(char)(212 + t)}");
            }*/
            


        }
    }
}