﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _23пр13
{
    public partial class Form2 : Form
    {
        public int Columns = 0, Rows = 0;
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (numericUpDown1.Value*numericUpDown2.Value%2!=1)
            {
                Columns = (int)numericUpDown1.Value;
                Rows = (int)numericUpDown2.Value;
                this.DialogResult = DialogResult.OK;
            }
            
        }
    }
}
