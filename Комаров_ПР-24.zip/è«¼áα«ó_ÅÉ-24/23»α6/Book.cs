﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _23пр6
{
    internal class Book
    {
        public string name;
        public string avtor;
        private int count_pages=0;
        private int price=0;
        public int Get_count_pages()
        {
            return count_pages;
        }
        public void Set_count_pages(int new_count_pages)
        {
            this.count_pages = new_count_pages;
        }
        public int Get_price()
        {
            return price;
        }
        public void Set_price(int new_price)
        {
            this.price = new_price;
        }
        public int Purchases_books(int k_books)
        {
            return k_books*price;
        }
        public Book()
        {

        }
        public Book(string name, string avtor, int count_pages, int price)
        {
            this.name = name;
            this.avtor = avtor;
            this.count_pages = count_pages;
            this.price = price;
        }
        
        public string Info ()
        {
            return $"name: {name}\navtor: {avtor}\nprice: {price}\ncount_pages: {count_pages}";
        }
    }
}
