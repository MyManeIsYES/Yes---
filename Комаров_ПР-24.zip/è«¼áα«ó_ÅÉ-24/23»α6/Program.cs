﻿namespace _23пр6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Book book1 = new Book();
            Console.Write("название книги: ");
            book1.name = Console.ReadLine();
            Console.Write("автор книги: ");
            book1.avtor = Console.ReadLine();
            Console.Write("количество страниц в книге: ");
            book1.Set_count_pages(int.Parse(Console.ReadLine()));
            Console.Write("цена: ");
            book1.Set_price(int.Parse(Console.ReadLine()));
            Console.WriteLine(book1.Info());
            Console.WriteLine("сколько хотите купить:");
            Console.WriteLine("Всего: "+book1.Purchases_books(int.Parse(Console.ReadLine())));

            Book book2 = new Book("№1093","№123",1123467,0);
            Console.WriteLine(book2.Info());
            Console.WriteLine("Всего: " + book2.Purchases_books(int.Parse(Console.ReadLine())));

        }
    }
}