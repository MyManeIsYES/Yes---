﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _23пр10ПТПМ
{
    public partial class Form1 : Form
    {
        class Worker
        {
            public string name;
            public int age;
            private double weight = 60;

            public double Get_weight()
            {
                return weight;
            }
            public void Set_new_weight(double eat)
            {
                if (eat>=10)
                {
                    weight += (eat/2);
                    age++;
                }
                else
                {
                    weight += eat;
                }
                
            }
            public void Set_weight(double new_weight)
            {
                this.weight=new_weight;
            }
            public Worker(string name, int age)
            {
                this.name = name;
                this.age = age;
            }
            public Worker(string name, int age,double weight)
            {
                this.name = name;
                this.age = age;
                this.weight = weight;
            }

        }

        public Form1()
        {
            InitializeComponent();

            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Worker worker1 = new Worker(textBox1.Text, (int)numericUpDown1.Value);
            worker1.Set_weight((double)numericUpDown2.Value);
            worker1.Set_new_weight((double)numericUpDown3.Value);
            MessageBox.Show($"name: {worker1.name}\nage: {worker1.age}\nweight: {worker1.Get_weight()}");
            worker1.Set_new_weight(4);
            MessageBox.Show($"name: {worker1.name}\nage: {worker1.age}\nweight: {worker1.Get_weight()}");
            worker1.Set_new_weight(40);
            MessageBox.Show($"name: {worker1.name}\nage: {worker1.age}\nweight: {worker1.Get_weight()}");

            Worker worker2 = new Worker("ds", 600);
            worker2.Set_new_weight(6);
            MessageBox.Show($"name: {worker2.name}\nage: {worker2.age}\nweight: {worker2.Get_weight()}");

            Worker worker3 = new Worker("ddfsdfsdfsdfsfdfss", 700,100);
            MessageBox.Show($"name: {worker3.name}\nage: {worker3.age}\nweight: {worker3.Get_weight()}");


        }
    }
}
