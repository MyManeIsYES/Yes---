﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using _23пр14;

namespace UnitTestProject1_23пр14
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            int w1 = 1, w2 = 1, h1 = 1, h2 = 1;
            
            
        }
    }
}
