﻿using System.Xml.Linq;


namespace _23пр8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n;
            do
            {
                Console.WriteLine("Начать бой монсров (y - да, n- нет)");
                ConsoleKeyInfo keyInfo = Console.ReadKey(true);
                if (keyInfo.Key == ConsoleKey.Y)
                {
                    Console.Clear();
                    Random random1 = new Random();
                    Monstr monstr1 = new Monstr();
                    Monstr monstr2 = new Monstr();
                    monstr1.Create_Monstr(50, 100, 5, 30);
                    monstr2.Create_Monstr(50, 100, 5, 30);
                    Console.WriteLine("+----");
                    monstr1.Get_Monstr();
                    Console.WriteLine("+----");
                    Thread.Sleep(1000);
                    Console.WriteLine("| против");
                    Console.WriteLine("+----");
                    Thread.Sleep(1000);
                    monstr2.Get_Monstr();
                    Console.WriteLine("+----");
                    Thread.Sleep(1000);
                    for (int i = 3; i > 0; i--)
                    {
                        Console.WriteLine(i);
                        Thread.Sleep(1000);
                    }

                    Console.WriteLine("+----\n| БОЙ");
                    int i0 = 1;
                    while (monstr1.Get_hp() > 0 && monstr2.Get_hp() > 0)
                    {
                        Console.WriteLine("+----");
                        Console.WriteLine($"| Раунд - {i0}");
                        if (random1.Next(0, 4) != 0)
                        {
                            monstr1.Set_hp_dmg(monstr2.Get_damage());
                            Console.WriteLine("+----");
                            Console.WriteLine("| " + monstr2.name + " попал");
                        }
                        else
                        {
                            Console.WriteLine("+----");
                            Console.WriteLine("| " + monstr2.name + " промахнулся");
                        }
                        Thread.Sleep(1000);
                        if (random1.Next(0, 4) != 0)
                        {
                            monstr2.Set_hp_dmg(monstr1.Get_damage());
                            Console.WriteLine("+----");
                            Console.WriteLine("| " + monstr1.name + " попал");
                        }
                        else
                        {
                            Console.WriteLine("+----");
                            Console.WriteLine("| "+monstr1.name+" промахнулся");
                        }
                        Thread.Sleep(1000);
                        Console.WriteLine("+----");
                        monstr1.Get_Monstr();
                        Console.WriteLine("+----");
                        monstr2.Get_Monstr();
                        Thread.Sleep(3000);
                        i0++;
                    }
                    if (monstr1.Get_hp() < 0 && monstr2.Get_hp() < 0)
                    {
                        Console.WriteLine("+----");
                        Console.WriteLine("| ничья");
                    }else
                    if (monstr1.Get_hp() > monstr2.Get_hp())
                    {
                        Console.WriteLine("+----");
                        Console.WriteLine("| Победил - " + monstr1.name);
                        
                    }
                    else
                    if (monstr1.Get_hp() < monstr2.Get_hp())
                    {
                        Console.WriteLine("+----");
                        Console.WriteLine("| Победил - " + monstr2.name);
                    }
                    Console.WriteLine("+----");
                }
                else
                if(keyInfo.Key == ConsoleKey.N)
                {
                    break;
                }
                else
                {
                    Console.Clear();
                }

            }
            while (true);
            
            
            

            /*for (int i=0;i<10;i++)
            {
                monstr1.Create_name();
                monstr1.Set_hp(75,100);
                monstr1.Set_damage(5,30);
                Console.WriteLine("+----");
                Console.WriteLine($"| Монстр: {monstr1.name}\n| Здроровье: {monstr1.Get_hp()}\n| Урон: {monstr1.Get_damage()}");
                if (monstr1.name == "Аномалия" && monstr1.Get_damage()>200 && monstr1.Get_hp()>200)
                {
                    Console.WriteLine(">>>>>БЕГИТЕ<<<<<");
                }
                Console.WriteLine("+----");
            }*/

        }
    }
}