using System.Windows.Forms;

namespace _23пр13._0
{
    public partial class Form1 : Form
    {
        int size = 4;
        Panel panel = new Panel();
        //int Columns, Rows;
        TableLayoutPanel table;

        public void set_size(int size) { this.size = size; }
        private void button_Click(object sender, EventArgs e)
        {
            int position = Convert.ToInt16(((Button)sender).Tag);
            game.shift(position);
            refresh();
        }
        private Button button(int position)
        {
            foreach (Control control in table.Controls)
            {
                Button button = control as Button;
                if (button != null)
                {
                    if (position == Convert.ToInt32(button.Tag)) return button;
                }
            }
            return null;
        }
        private void start_game()
        {
            game.start();
            for (int i=0;i<100*size;i++)
            {
                game.shift_random();
            }
            refresh();
        }
        private void refresh()
        {
            for (int position = 0; position < (size*size); position++)
            {
                int nr = game.get_number(position);
                button(position).Text = nr.ToString();
                button(position).Visible = (nr > 0);
            }
            if (game.the_end() == true)
            {
                MessageBox.Show("Вы выиграли!");
                this.Close();
                start_game();
                
            }
        }
        private void Crate_Table(int size)
        {

            panel.Controls.Clear();
            table = new TableLayoutPanel();
            


            panel.Width = Convert.ToInt32(this.Width * 0.9f);
            panel.Height = Convert.ToInt32(this.Height * 0.9f);
            table.Dock = DockStyle.Fill;
            table.CellBorderStyle = TableLayoutPanelCellBorderStyle.Inset;
            table.Location = new System.Drawing.Point(100, 100);
            table.Visible = true;
            table.ColumnCount = Convert.ToInt32(size);
            table.RowCount = Convert.ToInt32(size);

            int width = 100 / table.ColumnCount;
            int height = 100 / table.RowCount;

            int t = 0;
            for (int row = 0; row < table.RowCount; row++)
            {
                table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, width));
                for (int col = 0; col < table.ColumnCount; col++)
                {
                    if (col == 0)
                    {
                        table.RowStyles.Add(new RowStyle(SizeType.Percent, height));
                    }

                    var button = new Button();
                    button.AutoSize = false;
                    button.Font = new System.Drawing.Font("Segoe UI", 20.25F*width/100*4, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
                    button.Margin = new System.Windows.Forms.Padding(10);
                    button.Name = ("button" + t).ToString();
                    button.Tag = (t).ToString();
                    button.Text = (t).ToString();
                    button.TabIndex = t;
                    button.Dock = DockStyle.Fill;
                    button.TextAlign = ContentAlignment.MiddleCenter;
                    button.Click += new System.EventHandler(this.button_Click);
                    table.Controls.Add(button, col, row);
                    t++;
                }
            }
            Controls.Add(panel);
            panel.Controls.Add(table);
        }

        Game game;

        public Form1()
        {
            InitializeComponent();
            
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            game = new Game(size);
            Crate_Table(size);
            start_game();
        }
    }
}