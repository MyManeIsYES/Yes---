﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Remoting.Messaging;


namespace _23пр8ПТПМ
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                StreamWriter flowWriter1 = File.CreateText("file1.txt");
                if (textBox1.Text == "")
                    MessageBox.Show("Ошибка", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                else
                {
                    string str = "";
                    flowWriter1.WriteLine("ФИО: " + textBox1.Text);
                    foreach (RadioButton el in groupBox3.Controls.OfType<RadioButton>())
                        if (el.Checked)
                            str = el.Text;
                    if (str == "")
                        MessageBox.Show("Ошибка", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    else
                    {
                        flowWriter1.WriteLine("пол - " + str);
                        str = "";
                        foreach (RadioButton el in groupBox4.Controls.OfType<RadioButton>())
                            if (el.Checked)
                                str = el.Text;
                        if (str == "")
                            MessageBox.Show("Ошибка", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        else
                        {
                            flowWriter1.WriteLine("пол - " + str);
                            str = "";
                            foreach (RadioButton el in groupBox1.Controls.OfType<RadioButton>())
                                if (el.Checked)
                                    str = el.Text;
                            if (str == "")
                                MessageBox.Show("Ошибка", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            else
                            {
                                flowWriter1.WriteLine("время года-" + str);
                                str = "";
                                flowWriter1.WriteLine("думает что хорошо:");
                                foreach (CheckBox el in groupBox2.Controls.OfType<CheckBox>())
                                    if (el.Checked)
                                        str = str + '\n' + el.Text;
                                if (str == "")
                                {
                                    MessageBox.Show("Ошибка", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                                else
                                {
                                    flowWriter1.WriteLine(str);
                                    if (listBox1.Text == "")
                                    {
                                        MessageBox.Show("Ошибка", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    }
                                    else
                                    {
                                        flowWriter1.WriteLine("выбрал: " + listBox1.Text);
                                        if (numericUpDown1.TabIndex.ToString() == "")
                                        {
                                            MessageBox.Show("Ошибка", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                        }
                                        else
                                        {
                                            flowWriter1.WriteLine("число - " + numericUpDown1.TabIndex.ToString());
                                        }
                                    }
                                }
                                       

                            }

                        }
                    }


                }

                flowWriter1.Close();
            }
            catch
            {
                MessageBox.Show("Ошибка", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }


        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void radioButton11_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox4_Enter(object sender, EventArgs e)
        {

        }
    }
}
