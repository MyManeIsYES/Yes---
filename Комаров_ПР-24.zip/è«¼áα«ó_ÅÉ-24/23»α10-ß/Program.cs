﻿using ClassLibrary1_23пр10_с;

namespace _23пр10_с
{
    internal class Program
    {
        static bool f1(ref string str,string strread)
        {
            try
            {
                foreach (char el in strread)
                {
                    if (!char.IsLetter(el))
                    {
                        Console.WriteLine("error");
                        return true;
                    }
                }
                if (strread=="")
                {
                    Console.WriteLine("error");
                    return true;
                }
                str = strread;
            }
            catch
            {
                Console.WriteLine("error");
                return true;
            }
            return false;
        }
        static bool f2(ref int i,string str)
        {

            try
            {
                i = Convert.ToInt32(str);
                if (i < 0)
                {
                    Console.WriteLine("error");
                    return true;
                }
            }
            catch
            {
                Console.WriteLine("error");
                return true;
            }
            return false;
        }
        static void Main(string[] args)
        {
            List<Flight> flights = new List<Flight>();
            int i0=0;
            bool b = true;
            
            

            do
            {
                string str2 = "";
                int i3 = 0;
                bool b1 = true;
                int i2=0;

                do
                {
                    Console.Write("Выберети тип рейса (1-внутренний рейс, 2-международный рейс): ");
                    try
                    {
                        i2 = Convert.ToInt32(Console.ReadLine());
                        if (!(i2 == 2 || i2 == 1))
                        {
                            Console.WriteLine("error");
                            b1 = true;
                        }
                        else
                        {
                            b1 = false;
                        }
                    }
                    catch
                    {
                        Console.WriteLine("error");
                    }
                }
                while (b1);


                switch (i2)
                {
                    case 1:
                        Domestic_flight domestic_flight_0 = new Domestic_flight();
                        ////
                        i3 = 0;
                        do
                        {
                            Console.Write("введите номер рейса: ");
                        }
                        while (f2(ref i3, Console.ReadLine()));
                        domestic_flight_0.Flight_number = i3;
                        //
                        str2 = "";
                        do
                        {
                            Console.Write("введите пункт назначения: ");
                        }
                        while (f1(ref str2, Console.ReadLine()));
                        domestic_flight_0.Destination = str2;
                        //
                        str2 = "";
                        do
                        {
                            Console.Write("введите вид самолета: ");
                        }
                        while (f1(ref str2, Console.ReadLine()));
                        domestic_flight_0.Type_of_aircraft = str2;
                        //
                        i3 = 0;
                        do
                        {
                            Console.Write("введите время в пути: ");
                        }
                        while (f2(ref i3, Console.ReadLine()));
                        domestic_flight_0.Travel_time = i3;
                        ////
                        i3 = 0;
                        do
                        {
                            Console.Write("введите количество пассажиров: ");
                        }
                        while (f2(ref i3, Console.ReadLine()));
                        domestic_flight_0.Number_of_passengers = i3;
                        ////
                        flights.Add(domestic_flight_0);
                        break;

                    case 2:
                        International_flight international_flight_0 = new International_flight();
                        ////
                        i3 = 0;
                        do
                        {
                            Console.Write("введите номер рейса: ");
                        }
                        while (f2(ref i3, Console.ReadLine()));
                        international_flight_0.Flight_number = i3;
                        //
                        str2 = "";
                        do
                        {
                            Console.Write("введите пункт назначения: ");
                        }
                        while (f1(ref str2, Console.ReadLine()));
                        international_flight_0.Destination = str2;
                        //
                        str2 = "";
                        do
                        {
                            Console.Write("введите вид самолета: ");
                        }
                        while (f1(ref str2, Console.ReadLine()));
                        international_flight_0.Type_of_aircraft = str2;
                        //
                        i3 = 0;
                        do
                        {
                            Console.Write("введите время в пути: ");
                        }
                        while (f2(ref i3, Console.ReadLine()));
                        international_flight_0.Travel_time = i3;
                        ////
                        str2 = "";
                        do
                        {
                            Console.Write("введите страна назначения: ");
                        }
                        while (f1(ref str2, Console.ReadLine()));
                        international_flight_0.Destination_country = str2;
                        //
                        str2 = "";
                        do
                        {
                            Console.Write("введите промежуточные посадки: ");
                        }
                        while (f1(ref str2, Console.ReadLine()));
                        international_flight_0.Intermediate_landings = str2;
                        ////
                        flights.Add(international_flight_0);
                        break;
                }
                bool b0 = true;
                do 
                {
                    Console.Write("Добавить рейс (y/n): ");
                    string str0 = Console.ReadLine();
                    if (str0 == "n")
                    {
                        b0 = false;
                        b = false;
                    }
                    else
                    if (str0 == "y")
                    {
                        b0 = false;
                        b = true;
                    }
                    else
                    {
                        Console.WriteLine("error");
                    }
                }
                while (b0);
                i0++;
            } while (b);

            StreamWriter streamWriter1 = File.CreateText("file0.txt");
            for (int i = 0; i < flights.Count; i++)
            {
                streamWriter1.WriteLine($"{i+1}. {flights[i].Info()}");
                Console.WriteLine($"{i+1}. {flights[i].Info()}");
            }
            streamWriter1.Close();

        }
    }
}