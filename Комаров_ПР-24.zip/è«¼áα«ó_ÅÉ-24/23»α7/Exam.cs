﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _23пр7
{
    internal class Exam
    {
        //имя, фамилия, отчество, пол, группа, дата рождения, рост, вес, вид спорта
        public string name_student;
        private string obje;
        private string date_of_exam;
        private string estimation;
        public string Get_obje()
        {
            return obje;
        }
        public void Set_obje(string obje)
        {
            this.obje = obje;
        }

        public string Get_date_of_exam()
        {
            return date_of_exam;
        }
        public void Set_date_of_exam(string date_of_exam)
        {
            this.date_of_exam = date_of_exam;
        }
        public string Get_estimation()
        {
            return estimation;
        }
        public void Set_estimation(string estimation)
        {
            this.estimation = estimation;
        }

        public Exam()
        {

        }
        public Exam(string name_student)
        {
            this.name_student = name_student;
        }
        public Exam(string name_student,string obje, string date_of_exam,string estimation)
        {
            this.name_student= name_student;
            this.obje = obje;
            this.date_of_exam = date_of_exam;
            this.estimation = estimation;
        }

        public string Info()
        {
            return $"name_student: {name_student}\nobject: {obje}\ndate_of_exam: {date_of_exam}\nestimation: {estimation}";
        }
    }
}
