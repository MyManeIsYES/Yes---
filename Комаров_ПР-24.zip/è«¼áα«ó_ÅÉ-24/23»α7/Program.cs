﻿namespace _23пр7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Exam exam1 = new Exam();
            Console.Write("name_student: ");
            exam1.name_student = Console.ReadLine();
            Console.Write("object: ");
            exam1.Set_obje(Console.ReadLine());
            Console.Write("date_of_exam: ");
            exam1.Set_date_of_exam(Console.ReadLine());
            Console.Write("estimation: ");
            exam1.Set_estimation(Console.ReadLine());
            Console.WriteLine(exam1.Info());

            Exam exam2 = new Exam("№1","dd","22.22.33","100");
            Console.WriteLine(exam2.Info());
        }
    }
}