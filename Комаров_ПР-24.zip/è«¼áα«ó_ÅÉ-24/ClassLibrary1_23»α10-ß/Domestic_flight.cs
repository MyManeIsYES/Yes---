﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1_23пр10_с
{
    public class Domestic_flight : Flight
    {
        int number_of_passengers=0;

        public int Number_of_passengers { get; set; }
        public override string Info()
        {
            return $"flight_number: {Flight_number}\ndestination: {Destination}\ntype_of_aircraft: {Type_of_aircraft}\ntravel_time: {Travel_time}\nnumber_of_passengers: {Number_of_passengers}";
        }
    }
}
