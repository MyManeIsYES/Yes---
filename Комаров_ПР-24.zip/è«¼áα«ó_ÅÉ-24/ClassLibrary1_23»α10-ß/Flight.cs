﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1_23пр10_с
{
    abstract public class Flight
    {
        private string type_of_aircraft = "", destination="";
        private int flight_number = 0, travel_time = 0;
        public string Type_of_aircraft { get; set; }
        public string Destination { get; set; }
        public int Flight_number { get; set; }
        public int Travel_time { get; set; }
        public abstract string Info();
        
    }
}
