﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1_23пр10_с
{
    public class International_flight : Flight
    {
        string destination_country = "", intermediate_landings = "";
        public string Destination_country { get; set; }
        public string Intermediate_landings { get; set; }
        public override string Info()
        {
            return $"flight_number: {Flight_number}\ndestination: {Destination}\ntype_of_aircraft: {Type_of_aircraft}\ntravel_time: {Travel_time}\ndestination_country: {Destination_country}\nintermediate_landings: {Intermediate_landings}";
        }
    }
}
