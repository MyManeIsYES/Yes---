﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _23пр12
{
    abstract public class Function
    {
        public abstract List<Point> Draw(double a, double b, double c, double r, double t1, double t2);
    }
}
