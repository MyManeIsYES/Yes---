﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _23пр12
{
    public class Cubic_fun : Function
    {
        public override List<Point> Draw(double a, double b, double c, double r, double t1, double t2)
        {
            List<Point> f = new List<Point>();
            double y = 0;
            for (double x = t1; x <= t2; x++)
            {
                y = a + b * x * x * x;
                f.Add(new Point((int)x, (int)y));
            }
            return f;
        }
    }
}
