﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _23пр12
{
    public partial class Form1 : Form
    {
        Circle circle0=new Circle();
        Parabola parabola0=new Parabola();
        Cos_x_ cos0 = new Cos_x_();
        Sin_x_ sin0 = new Sin_x_();
        Cubic_fun cubic0 = new Cubic_fun();
        Hyperbola hyperbola0=new Hyperbola();
        public Form1()
        {
            InitializeComponent();
            comboBox1.SelectedIndex = 0;
        }

        static void Check_TextBox(string str,ref double num, ref string err)
        {
            if (str != "")
            {
                try
                {
                    num=Convert.ToDouble(str);
                }
                catch
                {
                    err="Неправильное значение";
                }
            }
            else
            {
                err="Пустое поле";
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBox1.SelectedIndex)
            {
                case 0:
                    textBox3.Visible = true;
                    textBox4.Visible = true;
                    textBox5.Visible = false;
                    textBox6.Visible = false;
                    break;
                case 1:
                    textBox3.Visible = true;
                    textBox4.Visible = true;
                    textBox5.Visible = false;
                    textBox6.Visible = false;
                    break;
                case 2:
                    textBox3.Visible = true;
                    textBox4.Visible = false;
                    textBox5.Visible = false;
                    textBox6.Visible = false;
                    break;
                case 3:
                    textBox3.Visible = true;
                    textBox4.Visible = true;
                    textBox5.Visible = true;
                    textBox6.Visible = false;
                    break;
                case 4:
                    textBox3.Visible = true;
                    textBox4.Visible = true;
                    textBox5.Visible = false;
                    textBox6.Visible = false;
                    break;
                case 5:
                    textBox3.Visible = false;
                    textBox4.Visible = false;
                    textBox5.Visible = false;
                    textBox6.Visible = true;
                    break;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double a = 0, b = 0,c=0, r = 0, max=0, min=0;
            string err = "";

            if (textBox1.Visible == true) Check_TextBox(textBox1.Text, ref max, ref err);
            if (textBox2.Visible == true) Check_TextBox(textBox2.Text, ref min, ref err);
            if (textBox3.Visible == true) Check_TextBox(textBox3.Text, ref a, ref err);
            if (textBox4.Visible == true) Check_TextBox(textBox4.Text, ref b, ref err);
            if (textBox5.Visible == true) Check_TextBox(textBox5.Text, ref c, ref err);
            if (textBox6.Visible == true) Check_TextBox(textBox6.Text, ref r, ref err);
            if (min >=max)
            {
                err = "min должно быть меньше max";
            }
            if (Math.Abs(min) > 1000 || Math.Abs(max) > 1000)
            {
                err = "Болшое значение";
            }
            if (err=="")
            {
                chart1.Series["Series3"].Points.Clear();
                double y = 0;
                List<Point> f=new List<Point>();
                switch (comboBox1.SelectedIndex)
                {
                    case 0:
                        f=sin0.Draw(a,b,c,r,min,max);
                        break;
                    case 1:
                        f = cos0.Draw(a, b, c, r, min, max);
                        break;
                    case 2:
                        f = hyperbola0.Draw(a, b, c, r, min, max);
                        
                        break;
                    case 3:
                        f=parabola0.Draw(a, b, c, r, min, max);
                        break;
                    case 4:
                        f=cubic0.Draw(a, b, c, r, min, max);
                        break;
                    case 5:
                        f=circle0.Draw(a, b, c, r, min, max);
                        /*for (double x=min; x>=max;x++)
                        {
                                y = Math.Sqrt(r * r - x * x);
                            chart1.Series["Series3"].Points.AddXY(x, y);
                        }
                        for (double x = max; x >= min; x--)
                        {
                                y = Math.Sqrt(r * r - x * x);
                            chart1.Series["Series3"].Points.AddXY(x, -y);
                        }*/
                        break;
                }
                for (int i = 0; i < f.Count; i++)
                {
                    chart1.Series["Series3"].Points.Add(f[i]);
                }
            }
            else
            {
                MessageBox.Show(err);
            }
        }
    }
}
