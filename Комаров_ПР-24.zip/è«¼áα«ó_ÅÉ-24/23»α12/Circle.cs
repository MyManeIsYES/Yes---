﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms.DataVisualization.Charting;

namespace _23пр12
{
    public class Circle : Function
    {
        public override List<Point> Draw(double a, double b, double c, double r, double t1, double t2)
        {
            List<Point> f = new List<Point>();
            double y = 0;
            int t = 1;
            for (double x = t1; x >= t1; x += t * 0.01)
            {
                if (x > t2)
                {
                    t = -1;
                }
                if (r * r - x * x >= 0)
                {
                    y = Math.Sqrt(r * r - x * x)*t;
                    f.Add(new Point((int)x, (int)y));
                }

            }
            return f;
        }
    }
}
