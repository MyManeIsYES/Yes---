﻿namespace _23пр3
{
    internal class Program
    {
        static void Main(string[] args)
        {


            
        }
    }
}