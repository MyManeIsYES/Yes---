using ClassLibrary1_23пр10_с;
using System.Windows.Forms;
using static System.Windows.Forms.DataFormats;

namespace WinFormsApp1_23пр10_с
{
    public partial class Form1 : Form
    {
        int flig = 0;
        List<Flight> flights = new List<Flight>();
        International_flight international_flight_0 = new International_flight();
        Domestic_flight domestic_flight_0 = new Domestic_flight();
        int i0 = 0;
        bool editing_mode = false;
        Form2 form2 = new Form2();
        private void Set_list_flights()
        {
            StreamReader streamReader0 = File.OpenText("fligts.txt");
            foreach (string el in streamReader0.ReadToEnd().Split(new string[] { "Рейс номер " }, StringSplitOptions.RemoveEmptyEntries))
            {
                string[] arrFligts = el.Split(new char[] { '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);
                if (arrFligts[1] == "внутренний рейс")
                {
                    domestic_flight_0 = new Domestic_flight();
                    domestic_flight_0.Flight_number = Convert.ToInt32(arrFligts[2].Substring(arrFligts[2].IndexOf(' ') + 1));
                    domestic_flight_0.Destination = arrFligts[3].Substring(arrFligts[3].IndexOf(' ') + 1);
                    domestic_flight_0.Type_of_aircraft = arrFligts[4].Substring(arrFligts[4].IndexOf(' ') + 1);
                    domestic_flight_0.Travel_time = Convert.ToInt32(arrFligts[5].Substring(arrFligts[5].IndexOf(' ') + 1));
                    domestic_flight_0.Number_of_passengers = Convert.ToInt32(arrFligts[6].Substring(arrFligts[6].IndexOf(' ') + 1));
                    flights.Add(domestic_flight_0);
                }
                if (arrFligts[1] == "международный рейс")
                {
                    international_flight_0 = new International_flight();
                    international_flight_0.Flight_number = Convert.ToInt32(arrFligts[2].Substring(arrFligts[2].IndexOf(' ') + 1));
                    international_flight_0.Destination = arrFligts[3].Substring(arrFligts[3].IndexOf(' ') + 1);
                    international_flight_0.Type_of_aircraft = arrFligts[4].Substring(arrFligts[4].IndexOf(' ') + 1);
                    international_flight_0.Travel_time = Convert.ToInt32(arrFligts[5].Substring(arrFligts[5].IndexOf(' ') + 1));
                    international_flight_0.Destination_country = arrFligts[6].Substring(arrFligts[6].IndexOf(' ') + 1);
                    international_flight_0.Intermediate_landings = arrFligts[7].Substring(arrFligts[7].IndexOf(' ') + 1);
                    flights.Add(international_flight_0);
                }
            }
            streamReader0.Close();
        }
        private bool Check_text(string str)
        {
            if (str == "")
            {
                MessageBox.Show("ошибка");
                return false;
            }
            else
            {
                foreach (char el in str)
                    if (!char.IsLetter(el))
                    {
                        MessageBox.Show("ошибка");
                        return false;
                    }

            }
            return true;
        }
        private void Clear_All()
        {
            numericUpDown1.Value = 0;
            numericUpDown2.Value = 1;
            numericUpDown3.Value = 1;
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            comboBox1.SelectedIndex = 0;
        }
        private void set_All(int i)
        {
            string[] arr = flights[i].Info().Split(new char[] { '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);
            numericUpDown1.Value = flights[i].Flight_number;
            textBox1.Text = flights[i].Destination;
            textBox2.Text = flights[i].Type_of_aircraft;
            numericUpDown2.Value = flights[i].Travel_time;

            if (flights[i].GetType() == international_flight_0.GetType())
            {
                label5.Visible = false;
                label6.Visible = true;
                label7.Visible = true;
                numericUpDown3.Visible = false;
                textBox3.Visible = true;
                textBox4.Visible = true;
                comboBox1.SelectedIndex = 1;

                textBox3.Text = arr[4].Substring(arr[4].IndexOf(' ') + 1);
                textBox4.Text = arr[5].Substring(arr[5].IndexOf(' ') + 1);


            }
            if (flights[i].GetType() == domestic_flight_0.GetType())
            {
                label5.Visible = true;
                label6.Visible = false;
                label7.Visible = false;
                numericUpDown3.Visible = true;
                textBox3.Visible = false;
                textBox4.Visible = false;
                comboBox1.SelectedIndex = 0;

                numericUpDown3.Value = Convert.ToInt32(arr[4].Substring(arr[4].IndexOf(' ')));


            }
        }
        private void set_listBox()
        {
            listBox1.Items.Clear();
            for (int i = 0; i < flights.Count; i++)
            {
                if (flights[i].GetType() == international_flight_0.GetType())
                {
                    listBox1.Items.Add($"Рейс номер {i + 1} ({flights[i].Flight_number}) - международный рейс");
                }
                if (flights[i].GetType() == domestic_flight_0.GetType())
                {
                    listBox1.Items.Add($"Рейс номер {i + 1} ({flights[i].Flight_number}) - внутренний рейс");
                }

            }
            listBox1.TabIndex = 0;
        }
        private void Check_num()
        {

        }


        public Form1()
        {
            InitializeComponent();
            panel1.Visible = true;
            label5.Visible = true;
            label6.Visible = false;
            label7.Visible = false;
            numericUpDown3.Visible = true;
            textBox3.Visible = false;
            textBox4.Visible = false;

            Set_list_flights();

            if (flights.Count !=0)
            {
                set_listBox();
                set_All(0);
            }
            if (flights.Count != 0) button2.Enabled = true; else button2.Enabled = false;

        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBox1.SelectedIndex)
            {
                case 0:
                    panel1.Visible = true;
                    label5.Visible=true;
                    label6.Visible = false;
                    label7.Visible = false;
                    numericUpDown3.Visible = true;
                    textBox3.Visible=false;
                    textBox4.Visible = false;

                    
                    

                    break;
                case 1:
                    panel1.Visible = true;
                    label5.Visible = false;
                    label6.Visible = true;
                    label7.Visible = true;
                    numericUpDown3.Visible = false;
                    textBox3.Visible = true;
                    textBox4.Visible = true;

                    
                    break;
            }
            flig=comboBox1.SelectedIndex;
        }
        

        private void button1_Click(object sender, EventArgs e)
        {
            Clear_All();
            if (flights.Count != 0) button2.Enabled = true; else button2.Enabled = false;
            button6.Enabled = false;
            button5.Enabled = false;
            listBox1.Enabled = false;
            button1.Enabled = false;
            button2.Enabled = false;
            button3.Visible = true;
            button4.Visible = true;
            comboBox1.Enabled = true;
            panel1.Enabled = true;
        }
        private void button2_Click(object sender, EventArgs e)
        {
            button6.Enabled =false;
            button5.Enabled = false;
            editing_mode = true;
            listBox1.Enabled = false;
            button1.Enabled = false;
            button2.Enabled = false;
            button3.Visible = true;
            button4.Visible = true;
            comboBox1.Enabled = true;
            panel1.Enabled = true;
            
        }
        private void button3_Click(object sender, EventArgs e)
        {
            if (flig == 0 && Check_text(textBox1.Text) && Check_text(textBox2.Text) ||
               flig == 1 && Check_text(textBox1.Text) && Check_text(textBox2.Text) && Check_text(textBox3.Text) && Check_text(textBox4.Text))
            {
                button6.Enabled = true;
                button5.Enabled = true;
                listBox1.Enabled = true;
                button1.Enabled = true;
                button2.Enabled = true;
                button3.Visible = false;
                button4.Visible = false;
                comboBox1.Enabled = false;
                panel1.Enabled = false;


                
                if (!editing_mode)
                {
                    switch (flig)
                    {
                        case 0:
                            domestic_flight_0 = new Domestic_flight();
                            domestic_flight_0.Flight_number = (int)numericUpDown1.Value;
                            domestic_flight_0.Destination = textBox1.Text;
                            domestic_flight_0.Type_of_aircraft = textBox2.Text;
                            domestic_flight_0.Travel_time = (int)numericUpDown2.Value;
                            domestic_flight_0.Number_of_passengers = (int)numericUpDown3.Value;
                            flights.Add(domestic_flight_0);
                            break;
                        case 1:
                            international_flight_0 = new International_flight();
                            international_flight_0.Flight_number = (int)numericUpDown1.Value;
                            international_flight_0.Destination = textBox1.Text;
                            international_flight_0.Type_of_aircraft = textBox2.Text;
                            international_flight_0.Travel_time = (int)numericUpDown2.Value;
                            international_flight_0.Destination_country = textBox3.Text;
                            international_flight_0.Intermediate_landings = textBox4.Text;
                            flights.Add(international_flight_0);
                            break;
                    }
                    
                }
                else
                {
                    
                    switch (flig)
                    {
                        case 0:
                            Domestic_flight domestic_flight_1 = new Domestic_flight();
                            domestic_flight_1.Flight_number = (int)numericUpDown1.Value;
                            domestic_flight_1.Destination = textBox1.Text;
                            domestic_flight_1.Type_of_aircraft = textBox2.Text;
                            domestic_flight_1.Travel_time = (int)numericUpDown2.Value;
                            domestic_flight_1.Number_of_passengers = (int)numericUpDown3.Value;

                            
                            flights[i0] = domestic_flight_1;

                            
                            break;
                        case 1:
                            International_flight international_flight_1 = new International_flight();
                            international_flight_1.Flight_number = (int)numericUpDown1.Value;
                            international_flight_1.Destination = textBox1.Text;
                            international_flight_1.Type_of_aircraft = textBox2.Text;
                            international_flight_1.Travel_time = (int)numericUpDown2.Value;
                            international_flight_1.Destination_country = textBox3.Text;
                            international_flight_1.Intermediate_landings = textBox4.Text;

                            
                            flights[i0] = international_flight_1;

                            
                            break;
                    }
                    editing_mode = false;
                    
                }
                if (flights.Count != 0) button2.Enabled = true; else button2.Enabled = false;
                set_listBox();
            }
        }
        private void button4_Click(object sender, EventArgs e)
        {
            if (flights.Count != 0) button2.Enabled = true; else button2.Enabled = false;
            editing_mode = false;
            button6.Enabled = true;
            listBox1.Enabled = true;
            button5.Enabled = true;
            button1.Enabled = true;
            button2.Enabled = true;
            button3.Visible = false;
            button4.Visible = false;
            comboBox1.Enabled = false;
            panel1.Enabled = false;
            Clear_All();
            if (flights.Count!=0)
            set_All(0);

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Clear_All();
            set_All(listBox1.SelectedIndex);
            i0 = listBox1.SelectedIndex;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            StreamWriter streamWriter0 = File.CreateText("fligts.txt");
            for (int i=0;i<flights.Count;i++)
            {
                streamWriter0.WriteLine($"Рейс номер {i + 1}");
                if (flights[i].GetType() == international_flight_0.GetType())
                {
                    streamWriter0.WriteLine($"международный рейс");
                }
                if (flights[i].GetType() == domestic_flight_0.GetType())
                {
                    streamWriter0.WriteLine($"внутренний рейс");
                }
                streamWriter0.WriteLine(flights[i].Info());
            }
            streamWriter0.Close();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            flights.RemoveAt(i0);
            i0 = 0;
            Clear_All();
            if(flights.Count!=0)set_All(0);
            if (flights.Count != 0) button2.Enabled = true; else button2.Enabled = false;
            set_listBox();
            
        }

        private void button7_Click(object sender, EventArgs e)
        {
            form2.ShowDialog();
        }
    }
}