﻿using ClassLibrary1_23пр10_с;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1_23пр10_с
{
    public partial class Form2 : Form
    {
        International_flight international_flight_0 = new International_flight();
        Domestic_flight domestic_flight_0 = new Domestic_flight();
        List<Flight> flights = new List<Flight>();
        List<Domestic_flight> domestic_flights = new List<Domestic_flight>();
        List<International_flight> international_flights = new List<International_flight>();
        private void Set_list_flights()
        {
            StreamReader streamReader0 = File.OpenText("fligts.txt");
            foreach (string el in streamReader0.ReadToEnd().Split(new string[] { "Рейс номер " }, StringSplitOptions.RemoveEmptyEntries))
            {
                string[] arrFligts = el.Split(new char[] { '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);
                if (arrFligts[1] == "внутренний рейс")
                {
                    domestic_flight_0 = new Domestic_flight();
                    domestic_flight_0.Flight_number = Convert.ToInt32(arrFligts[2].Substring(arrFligts[2].IndexOf(' ') + 1));
                    domestic_flight_0.Destination = arrFligts[3].Substring(arrFligts[3].IndexOf(' ') + 1);
                    domestic_flight_0.Type_of_aircraft = arrFligts[4].Substring(arrFligts[4].IndexOf(' ') + 1);
                    domestic_flight_0.Travel_time = Convert.ToInt32(arrFligts[5].Substring(arrFligts[5].IndexOf(' ') + 1));
                    domestic_flight_0.Number_of_passengers = Convert.ToInt32(arrFligts[6].Substring(arrFligts[6].IndexOf(' ') + 1));
                    flights.Add(domestic_flight_0);
                    domestic_flights.Add(domestic_flight_0);
                }
                if (arrFligts[1] == "международный рейс")
                {
                    international_flight_0 = new International_flight();
                    international_flight_0.Flight_number = Convert.ToInt32(arrFligts[2].Substring(arrFligts[2].IndexOf(' ') + 1));
                    international_flight_0.Destination = arrFligts[3].Substring(arrFligts[3].IndexOf(' ') + 1);
                    international_flight_0.Type_of_aircraft = arrFligts[4].Substring(arrFligts[4].IndexOf(' ') + 1);
                    international_flight_0.Travel_time = Convert.ToInt32(arrFligts[5].Substring(arrFligts[5].IndexOf(' ') + 1));
                    international_flight_0.Destination_country = arrFligts[6].Substring(arrFligts[6].IndexOf(' ') + 1);
                    international_flight_0.Intermediate_landings = arrFligts[7].Substring(arrFligts[7].IndexOf(' ') + 1);
                    flights.Add(international_flight_0);
                    international_flights.Add(international_flight_0);
                }
            }
            streamReader0.Close();
        }
        private void Create_Columns(int SelectedIndex_from_comboBox1)
        {
            dataGridView1.Columns.Clear();
            dataGridView1.Columns.Add("column-1", "номер");
            dataGridView1.Columns.Add("column-2", "flight_number");
            dataGridView1.Columns.Add("column-3", "destination");
            dataGridView1.Columns.Add("column-4", "type_of_aircraft");
            dataGridView1.Columns.Add("column-5", "travel_time");
            switch (SelectedIndex_from_comboBox1)
            {
                case 0:
                    dataGridView1.Columns.Add("column-6", "number_of_passengers");
                    break;
                case 1:
                    dataGridView1.Columns.Add("column-6", "destination_country");
                    dataGridView1.Columns.Add("column-7", "intermediate_landings");
                    break;
            }
        }
        private void Create_Tab(int SelectedIndex_from_comboBox1)
        {
            Create_Columns(SelectedIndex_from_comboBox1);
            switch (SelectedIndex_from_comboBox1)
            {
                case 0:
                    for (int i = 0; i < domestic_flights.Count; i++)
                    {
                        dataGridView1.Rows.Add(
                            i + 1,
                            domestic_flights[i].Flight_number,
                            domestic_flights[i].Destination,
                            domestic_flights[i].Type_of_aircraft,
                            domestic_flights[i].Travel_time,
                            domestic_flights[i].Number_of_passengers
                            );
                    }
                    break;
                case 1:
                    for(int i=0;i<international_flights.Count;i++) 
                    {
                        dataGridView1.Rows.Add(
                            i+1, 
                            international_flights[i].Flight_number,
                            international_flights[i].Destination,
                            international_flights[i].Type_of_aircraft,
                            international_flights[i].Travel_time,
                            international_flights[i].Destination_country,
                            international_flights[i].Intermediate_landings
                            );
                    }
                    break;
            }dataGridView1.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
        }
        private void Set_comboBox2(int SelectedIndex)
        {
            comboBox2.Items.Clear();
            comboBox2.Items.Add("номер");
            comboBox2.Items.Add("flight_number");
            comboBox2.Items.Add("destination");
            comboBox2.Items.Add("type_of_aircraft");
            comboBox2.Items.Add("travel_time");
            switch (SelectedIndex)
            {
                case 0:
                    comboBox2.Items.Add("number_of_passengers");
                    break;
                case 1:
                    comboBox2.Items.Add("destination_country");
                    comboBox2.Items.Add("intermediate_landings");
                    break;
            }
            comboBox2.SelectedIndex=0;
        }
        private void Set_Tab(int SelectedIndex_from_comboBox1, int SelectedIndex_from_comboBox2, decimal value, string text, int comparison)
        {
            Create_Columns(SelectedIndex_from_comboBox1);
            switch (SelectedIndex_from_comboBox1)
            {
                case 0:
                    for (int i = 0; i < domestic_flights.Count; i++)
                    {
                        if (
                            SelectedIndex_from_comboBox2 == 0 && Comparison_value(i + 1, comparison, value) ||
                            SelectedIndex_from_comboBox2 == 1 && Comparison_value(domestic_flights[i].Flight_number, comparison, value) ||
                            SelectedIndex_from_comboBox2 == 2 && domestic_flights[i].Destination == text ||
                            SelectedIndex_from_comboBox2 == 3 && domestic_flights[i].Type_of_aircraft == text ||
                            SelectedIndex_from_comboBox2 == 4 && Comparison_value(domestic_flights[i].Travel_time, comparison, value) ||
                            SelectedIndex_from_comboBox2 == 5 && Comparison_value(domestic_flights[i].Number_of_passengers, comparison, value)
                            )
                            dataGridView1.Rows.Add(
                                i + 1,
                                domestic_flights[i].Flight_number,
                                domestic_flights[i].Destination,
                                domestic_flights[i].Type_of_aircraft,
                                domestic_flights[i].Travel_time,
                                domestic_flights[i].Number_of_passengers
                                );
                    }
                    break;
                case 1:
                    for (int i = 0; i < international_flights.Count; i++)
                    {
                        if (
                            SelectedIndex_from_comboBox2 == 0 && Comparison_value(i + 1, comparison, value) ||
                            SelectedIndex_from_comboBox2 == 1 && Comparison_value(international_flights[i].Flight_number, comparison, value) ||
                            SelectedIndex_from_comboBox2 == 2 && international_flights[i].Destination == text ||
                            SelectedIndex_from_comboBox2 == 3 && international_flights[i].Type_of_aircraft == text ||
                            SelectedIndex_from_comboBox2 == 4 && Comparison_value(international_flights[i].Travel_time, comparison, value) ||
                            SelectedIndex_from_comboBox2 == 6 && international_flights[i].Destination_country == text ||
                            SelectedIndex_from_comboBox2 == 7 && international_flights[i].Intermediate_landings == text
                            )
                            dataGridView1.Rows.Add(
                            i + 1,
                            international_flights[i].Flight_number,
                            international_flights[i].Destination,
                            international_flights[i].Type_of_aircraft,
                            international_flights[i].Travel_time,
                            international_flights[i].Destination_country,
                            international_flights[i].Intermediate_landings
                            );
                    }
                    break;
            }
        }
        private bool Comparison_value(int num, int comparison, decimal value)
        {
            
            switch (comparison)
            {
                case 0:
                    //=
                    if (num == value) return true;
                    break;
                case 1:
                    //>=
                    if (num !>= value) return true;
                    break;
                case 2:
                    //<=
                    if (num <= value) return true;
                    break;
                case 3:
                    //>
                    if (num > value) return true;
                    break;
                case 4:
                    //<
                    if (num < value) return true;
                    break;
                case 5:
                    //!=
                    if(num != value) return true;
                    break;
            }
            return false;
        }
        private bool Check_text(string str)
        {
            if (str == "")
            {
                return false;
            }
            else
            {
                foreach (char el in str)
                    if (!char.IsLetter(el))
                    {
                        return false;
                    }

            }
            return true;
        }
        public Form2()
        {
            InitializeComponent();
            Set_list_flights();
            Create_Tab(0);
            Set_comboBox2(0);
            
            
            /*dataGridView1.DataSource = domestic_flights;*/
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Create_Tab(comboBox1.SelectedIndex);
            Set_comboBox2(comboBox1.SelectedIndex);
            Set_search(0);
            /*switch (comboBox1.SelectedIndex)
            {
                case 0:
                    dataGridView1.DataSource = domestic_flights;
                    break;
                case 1:
                    dataGridView1.DataSource = international_flights;
                    break;
            }*/
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Check_text(textBox1.Text) || numericUpDown1.Visible)
                Set_Tab(comboBox1.SelectedIndex, comboBox2.SelectedIndex, numericUpDown1.Value, textBox1.Text, comboBox3.SelectedIndex);
            else MessageBox.Show("ошибка");
        }
        private void Set_search(int selectedIndex_from_combobox2)
        {
            bool b = true;
            switch (selectedIndex_from_combobox2)
            {
                case 0: b = true; break;
                case 1: b = true; break;
                case 2: b = false; break;
                case 3: b = false; break;
                case 4: b = true; break;
                case 5: b = true; break;
                case 6: b = false; break;
                case 7: b = false; break;
            }
            numericUpDown1.Visible = b;
            textBox1.Visible = !b;
            comboBox3.Visible = b;
            numericUpDown1.Value = 1;
            textBox1.Text = "";
            comboBox3.SelectedIndex = 0;
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            Set_search(comboBox2.SelectedIndex);
        }
    }
}
