﻿namespace _23пр5
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.заданииToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.задание1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.кругиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.квадратыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.задание2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.задание3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.задание4ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.задание5ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.задание6ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.очиститьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.линииToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.задание10ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.задание11ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.заданииToolStripMenuItem,
            this.очиститьToolStripMenuItem,
            this.линииToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(784, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // заданииToolStripMenuItem
            // 
            this.заданииToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.задание1ToolStripMenuItem,
            this.задание2ToolStripMenuItem,
            this.задание3ToolStripMenuItem,
            this.задание4ToolStripMenuItem,
            this.задание5ToolStripMenuItem,
            this.задание6ToolStripMenuItem,
            this.задание10ToolStripMenuItem,
            this.задание11ToolStripMenuItem});
            this.заданииToolStripMenuItem.Name = "заданииToolStripMenuItem";
            this.заданииToolStripMenuItem.Size = new System.Drawing.Size(63, 20);
            this.заданииToolStripMenuItem.Text = "задании";
            // 
            // задание1ToolStripMenuItem
            // 
            this.задание1ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.кругиToolStripMenuItem,
            this.квадратыToolStripMenuItem});
            this.задание1ToolStripMenuItem.Name = "задание1ToolStripMenuItem";
            this.задание1ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.задание1ToolStripMenuItem.Text = "задание1";
            // 
            // кругиToolStripMenuItem
            // 
            this.кругиToolStripMenuItem.Name = "кругиToolStripMenuItem";
            this.кругиToolStripMenuItem.Size = new System.Drawing.Size(125, 22);
            this.кругиToolStripMenuItem.Text = "круги";
            this.кругиToolStripMenuItem.Click += new System.EventHandler(this.кругиToolStripMenuItem_Click);
            // 
            // квадратыToolStripMenuItem
            // 
            this.квадратыToolStripMenuItem.Name = "квадратыToolStripMenuItem";
            this.квадратыToolStripMenuItem.Size = new System.Drawing.Size(125, 22);
            this.квадратыToolStripMenuItem.Text = "квадраты";
            this.квадратыToolStripMenuItem.Click += new System.EventHandler(this.квадратыToolStripMenuItem_Click);
            // 
            // задание2ToolStripMenuItem
            // 
            this.задание2ToolStripMenuItem.Name = "задание2ToolStripMenuItem";
            this.задание2ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.задание2ToolStripMenuItem.Text = "задание2";
            this.задание2ToolStripMenuItem.Click += new System.EventHandler(this.задание2ToolStripMenuItem_Click);
            // 
            // задание3ToolStripMenuItem
            // 
            this.задание3ToolStripMenuItem.Name = "задание3ToolStripMenuItem";
            this.задание3ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.задание3ToolStripMenuItem.Text = "задание3";
            this.задание3ToolStripMenuItem.Click += new System.EventHandler(this.задание3ToolStripMenuItem_Click);
            // 
            // задание4ToolStripMenuItem
            // 
            this.задание4ToolStripMenuItem.Name = "задание4ToolStripMenuItem";
            this.задание4ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.задание4ToolStripMenuItem.Text = "задание4";
            this.задание4ToolStripMenuItem.Click += new System.EventHandler(this.задание4ToolStripMenuItem_Click);
            // 
            // задание5ToolStripMenuItem
            // 
            this.задание5ToolStripMenuItem.Name = "задание5ToolStripMenuItem";
            this.задание5ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.задание5ToolStripMenuItem.Text = "задание5";
            this.задание5ToolStripMenuItem.Click += new System.EventHandler(this.задание5ToolStripMenuItem_Click);
            // 
            // задание6ToolStripMenuItem
            // 
            this.задание6ToolStripMenuItem.Name = "задание6ToolStripMenuItem";
            this.задание6ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.задание6ToolStripMenuItem.Text = "задание6";
            this.задание6ToolStripMenuItem.Click += new System.EventHandler(this.задание6ToolStripMenuItem_Click);
            // 
            // очиститьToolStripMenuItem
            // 
            this.очиститьToolStripMenuItem.Name = "очиститьToolStripMenuItem";
            this.очиститьToolStripMenuItem.Size = new System.Drawing.Size(69, 20);
            this.очиститьToolStripMenuItem.Text = "очистить";
            this.очиститьToolStripMenuItem.Click += new System.EventHandler(this.очиститьToolStripMenuItem_Click);
            // 
            // линииToolStripMenuItem
            // 
            this.линииToolStripMenuItem.Name = "линииToolStripMenuItem";
            this.линииToolStripMenuItem.Size = new System.Drawing.Size(54, 20);
            this.линииToolStripMenuItem.Text = "линии";
            this.линииToolStripMenuItem.Click += new System.EventHandler(this.линииToolStripMenuItem_Click);
            // 
            // задание10ToolStripMenuItem
            // 
            this.задание10ToolStripMenuItem.Name = "задание10ToolStripMenuItem";
            this.задание10ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.задание10ToolStripMenuItem.Text = "задание10";
            this.задание10ToolStripMenuItem.Click += new System.EventHandler(this.задание10ToolStripMenuItem_Click);
            // 
            // задание11ToolStripMenuItem
            // 
            this.задание11ToolStripMenuItem.Name = "задание11ToolStripMenuItem";
            this.задание11ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.задание11ToolStripMenuItem.Text = "задание11";
            this.задание11ToolStripMenuItem.Click += new System.EventHandler(this.задание11ToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 761);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem заданииToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem задание1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem кругиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem квадратыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem очиститьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem линииToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem задание2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem задание3ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem задание4ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem задание5ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem задание6ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem задание10ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem задание11ToolStripMenuItem;
    }
}

