﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TreeView;

namespace _23пр5
{
    public partial class Form1 : Form
    {
        Graphics g;
        public Form1()
        {
            InitializeComponent();
            
        }
        private void линииToolStripMenuItem_Click(object sender, EventArgs e)
        {
            g = this.CreateGraphics();
            g.DrawLine(Pens.Black, 0, Height / 2, Width, Height / 2);
            g.DrawLine(Pens.Black, Width / 2, 0, Width / 2, Height);
            g.Dispose();
        }

        int sd = 24;
        private void очиститьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            g = this.CreateGraphics();
            g.Clear(Color.WhiteSmoke);
            
            g.Dispose();
            
        }
        private void кругиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            g = this.CreateGraphics();
            p1(g,10,50,50,5,0);
            g.Dispose();
        }

        private void квадратыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            g = this.CreateGraphics();
            p1(g, 10, 50, 50, 5, 1);
            g.Dispose();
        }
        private void p1(Graphics g,int n, int x,int y,int m,int s)
        {
            if (n > 0)
            {
                switch(s)
                {
                    case 0:
                        g.DrawEllipse(Pens.Black, Width / 2 - x, Height / 2 - y, x * 2, y * 2);
                        break;
                    case 1:
                        g.DrawRectangle(Pens.Black, Width / 2 - x, Height / 2 - y, x * 2, y * 2);
                        break;
                }
                x += m;
                y += m;
                n--;
                p1(g,n,x,y,m,s);
            }
        }
        //
        private void задание2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            g = this.CreateGraphics();
            p2(g, 10, 10, 10, 20);
            g.Dispose();
        }
        private void p2(Graphics g, int n, int x, int y, int p)
        {
            if (n > 0)
            {
                g.DrawEllipse(Pens.Black, x, y+sd, x, y);
                x += p;
                y += p;

                p2(g, n-1, x, y, p);
            }
        }
        //
        private void задание3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int r = 100, n = 10,p=3;
            g = this.CreateGraphics();
            /*g.DrawEllipse(Pens.Black, (Width)/2-r, (Height)/2-r, r * 2, r * 2);*/
            p3(g, n, 10, 10, p, r,0,n);
            g.Dispose();
        }
        private void p3(Graphics g, int n, int xr, int yr, int p,int r,float degrees,int n1)
        {
            if (n > 0)
            {
                g.DrawEllipse(Pens.Black, Convert.ToSingle(Width / 2+Math.Cos(degrees * Math.PI / 180) *r)-xr, Convert.ToSingle(Height / 2-Math.Sin(degrees * Math.PI / 180) *r)-xr, xr*2, yr*2);
                xr += p;
                yr += p;

                p3(g, n - 1, xr, yr, p,r,degrees+(360/n1),n1);
            }
        }
        //
        private void задание4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int r = 200, n = 10, p = 5,m=20;
            g = this.CreateGraphics();
            /*g.DrawEllipse(Pens.Black, (Width)/2-r, (Height)/2-r, r * 2, r * 2);*/
            p4(g, n, 10, 10, p, r, 0, n,m);
            g.Dispose();
        }
        private void p4(Graphics g, int n, int xr, int yr, int p, int r, float degrees, int n1,int m)
        {
            if (n > 0)
            {
                g.DrawEllipse(Pens.Black, Convert.ToSingle(Width / 2 + Math.Cos(degrees * Math.PI / 180) * r) - xr, Convert.ToSingle(Height / 2 - Math.Sin(degrees * Math.PI / 180) * r) - xr, xr * 2, yr * 2);
                xr += p;
                yr += p;

                p4(g, n - 1, xr, yr, p, r-m, degrees + (360 / n1), n1,m);
            }
        }
        //
        private void задание5ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int n = 7, branches=3,r=100;
            g = this.CreateGraphics();
            p5(g, n, branches,r, Width / 2, Height / 2,90);
            g.Dispose();
        }
        private void p5(Graphics g, int n, double branches, double r,int x0, int y0,double degrees)
        {
            if (n > 0)
            {
                int x1 = x0 + Convert.ToInt32(Math.Cos(degrees * Math.PI / 180) * r),
                    y1 = y0 - Convert.ToInt32(Math.Sin(degrees * Math.PI / 180) * r);
                g.DrawLine(Pens.Red, x0, y0, x1, y1);
                degrees += (180 / branches / 2-90);
                for (int i = 0; i < branches; i++)
                {
                    p5(g, n - 1, branches, r / 2, x1, y1, degrees);
                    degrees += (180 / branches);
                }
                
                
            }
        }
        //
        private void задание6ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int n = 10,r=10, branches=2,lmin=10,lmax=100;
            g = this.CreateGraphics();
            g.Clear(Color.WhiteSmoke);
            /*p6(g, n, 0, 0, r, branches, lmin, lmax);*/
            g.Dispose();
        }
        private void p6(Graphics g, int n, int x0, int y0,int r,int branches,int lmin,int lmax)
        {
            Random random=new Random();
            if (n > 0)
            {
                int l = random.Next(lmin,lmax+1),
                    x1 = random.Next(lmin, l + 1)+x0,
                    y1 = Convert.ToInt32(Math.Sqrt(l*l-x1*x1));
                g.DrawEllipse(new Pen(Color.Red,1), x1-r,y1-r , r*2, r*2);
                g.DrawLine(new Pen(Color.Black, 1), x0, y0, x1, y1);
                for (int i = 0; i < branches; i++)
                {
                    p6(g, n - 1, x1, y1, r, branches,lmin, lmax);
                }
               
            }
        }
        //
        private void задание10ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int n = 5, x0 = 50, y0 = 50, r = 700;
            g = this.CreateGraphics();
            g.Clear(Color.WhiteSmoke);
            p10(g, n, x0, y0, r, n);
            g.Dispose();
        }

        private void p10(Graphics g, int n, float x0, float y0, float r,int n0)
        {
            if(n0==n) g.FillRectangle(Brushes.Black, x0, y0, r, r);
            if (n > 0)
            {
                g.FillRectangle(Brushes.White, x0 + r / 3, y0 + r / 3, r / 3, r / 3);
                for (int i = 0; i <= 3; i++)
                    for (int j = 0; j <= 3; j++)
                        if (i != 1 || j != 1)
                            p10(g, n - 1, x0 + r / 3 * i, y0 + r / 3 * j, r / 3, n0);
            }
        }

        //
        private void задание11ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int n = 5, x0 = 50, y0 = 50, r = 700;
            g = this.CreateGraphics();
            g.Clear(Color.WhiteSmoke);
            p11(g, n, x0, y0, r, n);
            g.Dispose();
        }
        private void p11(Graphics g, int n, int x0, int y0, int r, int n0)
        {
            int h = Convert.ToInt32(Math.Sqrt(r * r - (r * r) / 4));
            if (n0 == n) 
            {
                g.FillPolygon(Brushes.Black, new Point[] { new Point(x0 + r / 2, y0), new Point(x0, Convert.ToInt32(y0 + (Math.Sqrt(r * r - (r * r) / 4)))), new Point(x0 + r, y0 + h) });
            }
            if (n > 0)
            {
                g.FillPolygon(Brushes.White, new Point[] { new Point(x0 + r / 4 * 2, y0 + h), new Point(x0 + r / 4 * 1, y0 + h / 2), new Point(x0 + r / 4 * 3, y0 + h / 2) });
                p11(g, n - 1, x0 + r / 4 * 2, y0 + h / 2 * 1, r / 2, n);
                p11(g, n - 1, x0 + r / 4 * 1, y0 + h / 2 * 0, r / 2, n);
                p11(g, n - 1, x0 + r / 4 * 0, y0 + h / 2 * 1, r / 2, n);

            }
        }
    }
}
