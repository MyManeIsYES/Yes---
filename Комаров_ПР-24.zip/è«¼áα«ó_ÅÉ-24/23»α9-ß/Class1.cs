﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace _23пр9_с
{
    internal class Cake
    {
        //name, dough, weight, calorie content, price
        private string name = "", dough = "";
        private double weight = 0, calorie_content = 0, price = 0;
        static private double cost_buying_cakes = 0;

        public string Info()
        {
            return $"Название: {name}\nТесто: {dough}\nВес: {weight}\nКалорийность: {calorie_content}\nЦена: {price}";
        }
        public double Cost_cakes_specific_type(uint number_сakes)
        {
            return price * number_сakes;
        }
        public void Calculation_cost_buying_cakes(uint number_сakes)
        {
            cost_buying_cakes += price * number_сakes;
        }
        public string Dough
        {
            get { return dough; }
            set
            {
                foreach (char ch in value.ToString())
                {
                    if (char.IsLetter(ch))
                    {
                        dough = value;
                    }
                    else
                    {
                        dough = "";
                        Console.WriteLine("error");
                        break;
                    }
                }  
            }
        }

        public string Name
        {
            get { return name; }
            set 
            {
                foreach (char ch in value.ToString())
                {
                    if (char.IsLetter(ch))
                    {

                        name = value;
                    }
                    else
                    {
                        name = "";
                        Console.WriteLine("error");
                        break;
                    }
                }
            }
        }
        public double Cost_buying_cakes
        {
            get { return cost_buying_cakes; }
            set
            {
                if (value>0)
                {
                    cost_buying_cakes = value;
                }
                else
                {
                    Console.WriteLine("error");
                }
            }
        }
        public double Weight 
        {
            get { return weight; }
            set
            {
                if (value > 0)
                {
                    weight = value;
                }
                else
                {
                    weight = 0;
                    Console.WriteLine("error");
                }
            }
        }
        public double Calorie_content
        {
            get { return calorie_content; }
            set
            {
                if (value > 0)
                {
                    calorie_content = value;
                }
                else
                {
                    calorie_content = 0;
                    Console.WriteLine("error");
                }
            }
        }
        public double Price
        {
            get { return price; }
            set
            {
                if (value > 0)
                {
                    price = value;
                }
                else
                {
                    price = 0;
                    Console.WriteLine("error");
                }
            }
        }
        public string Calculation_calorie_content()
        {
            return $"Энергетическая ценность на вес: {Math.Round(calorie_content / weight,2)}\nЦена на калории: {Math.Round(price / calorie_content,2)}";
        }
        /*public Cake(string name, string dough, double weight, double calorie_content, double price)
        {
            this.name = name;
            this.dough = dough;
            this.weight = weight;
            this.calorie_content = weight;
            this.price = weight;
        }
        public Cake()
        {

        }*/
        
    }
}
