﻿namespace _23пр9_с
{
    internal class Program
    {
        static void Main(string[] args)
        {
            bool b = true;
            List<Cake> cakes = new List<Cake>();
            int i0 = 0;
            do
            {
                cakes.Add(new Cake());
                do
                {
                    Console.Write("Name: ");
                    cakes[i0].Name = Console.ReadLine();
                }
                while (cakes[i0].Name=="");
                do
                {
                    Console.Write("Dough: ");
                    cakes[i0].Dough = Console.ReadLine();
                }
                while (cakes[i0].Dough == "");
                do
                {
                    Console.Write("Weight: ");
                    try
                    {
                        cakes[i0].Weight = Convert.ToDouble(Console.ReadLine());
                    }
                    catch
                    {
                        Console.WriteLine("error");
                    }
                }
                while (cakes[i0].Weight == 0);
                do
                {
                    Console.Write("Calorie_content: ");
                    try
                    {
                        cakes[i0].Calorie_content = Convert.ToDouble(Console.ReadLine());
                    }
                    catch 
                    {
                        Console.WriteLine("error");
                    }
                }
                while (cakes[i0].Calorie_content == 0);
                do
                {
                    Console.Write("Price: ");
                    try
                    {
                        cakes[i0].Price = Convert.ToDouble(Console.ReadLine());
                    }
                    catch
                    {
                        Console.WriteLine("error");
                    }

                }
                while (cakes[i0].Price == 0);
                    Console.Write("Добавить пирожоное (y/n):");
                    string str0 = Console.ReadLine();
                    if (str0 == "n")
                    {
                        b = false;
                    }
                    else
                    if (str0 == "y")
                    {
                        b = true;
                    }
                    else
                    {
                        Console.WriteLine("error");
                    }
            

                i0++;
            }
            while (b);
            Console.Clear();
            for (int i=0; i<cakes.Count;i++)
            {
                b = true;
                do
                {
                    try
                    {
                        Console.Write($"{i+1}. {cakes[i].Info()} \nСколько вы хотите {cakes[i].Name}: ");
                        cakes[i].Calculation_cost_buying_cakes(Convert.ToUInt32(Console.ReadLine()));
                        b = false;
                    }
                    catch
                    {
                        Console.WriteLine("error");
                    }
                }
                while (b);
            }
            Console.WriteLine($"Итого: {Math.Round(cakes[0].Cost_buying_cakes,2)}");
            
        }
    }
}