﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _23пр4ПТПМ
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }
        private string Check_Login(string text)
        {
            string mes = "";
            if (text=="")
                mes = "Поле логин не заполнен";
            else
                if (text.Length<3||text.Length>20)
                    mes = "логин должен быть от 3 до 20";
                else
                    for (int i=0;i<text.Length;i++)
                        if (!(char.IsLetter(text[i])))
                            mes = "Логин можно писать только буквы";
            return mes;
        }
        private string Check_Telephone(string text)
        {
            string mes = "";
            if (text == "")
            {
                mes = "Поле телефон не заполнен";
            }
            else
            {
                if (text[0] != '+' || text[1] != '7')
                {
                    mes = "Телефон должен выгледить: +7xxxxxxxxxx";
                }
                else 
                {
                    if (text.Length != 12)
                    {
                        mes = "телефон должен быть 12 знаков";
                    }
                    else
                    {
                        for (int i = 2; i < text.Length; i++)
                            if (!(char.IsDigit(text[i])))
                            {
                                mes = "Телефон можно писать только цифры";
                            }
                    }
                }
            }
            return mes;
        }
        private string Check_Mail(string text)
        {
            string mes = "";
            if (text == "")
            {
                mes = "Поле почта не заполнен";
            }
            else
            {
                if (text.Length < 5)
                {
                    mes = "Почта должен быть больше 5 знаков";
                }
                else
                {
                    for (int i = 0; i < text.Length; i++)
                    {
                        if (text[i]=='@'|| text[i]=='.')
                        {
                            continue;
                        }
                        if (!(char.IsLetterOrDigit(text[i])))
                        {
                            mes = "Почта можно писать только цифры и буквы";
                        }
                    }
                    if (text.IndexOf('@')==0 || text.IndexOf('@') == text.Length-1)
                    {
                        mes = "В почте \'@\' после и до должен быть один символ";
                    }
                    if (text.IndexOf('.') == text.Length-1)
                    {
                        mes = "В почте \'.\' после один символ";
                    }
                    if (text.IndexOf('@') != text.LastIndexOf('@'))
                    {
                        mes = "Почта можно писать только один знак \'@\'";
                    }
                    if (text.IndexOf('.') != text.LastIndexOf('.'))
                    {
                        mes = "Почта можно писать только один знак \'.\'";
                    }
                    if (!text.Contains("."))
                    {
                        mes = "В почте не знака \'.\'";
                    }
                    if (!text.Contains("@"))
                    {
                        mes = "В почте не знака \'@\'";
                    }

                }
            }
            return mes;
            
        }
        private void button1_Click(object sender, EventArgs e)
        {
            string
            message1 = Check_Login(textBox1.Text),
            message2 = Check_Telephone(textBox2.Text),
            message3 = Check_Mail(textBox3.Text);
           
            
            if (message1 == "" && message2 == "" && message3 == "") MessageBox.Show("регистрация прошла успешно","", MessageBoxButtons.OK, MessageBoxIcon.Information);
            else
            {
                if(message1 != "") MessageBox.Show(message1,"Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                else
                if (message2 != "") MessageBox.Show(message2, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                else
                if (message3 != "") MessageBox.Show(message3, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
    }
}
