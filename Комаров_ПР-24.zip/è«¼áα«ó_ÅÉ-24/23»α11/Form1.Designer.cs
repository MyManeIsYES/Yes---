﻿namespace _23пр11
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.столбецыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.добавитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.удалитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.цветToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.строкиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.добавитьToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.удалитьToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.задатьТекстВЗаголовкеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выравниваниеЗаголовкаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.задатьШрифтВЗаголовкеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.размерToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ширинаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выравниваниеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.инфКToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.столбецыToolStripMenuItem,
            this.строкиToolStripMenuItem,
            this.задатьТекстВЗаголовкеToolStripMenuItem,
            this.выравниваниеЗаголовкаToolStripMenuItem,
            this.задатьШрифтВЗаголовкеToolStripMenuItem,
            this.размерToolStripMenuItem,
            this.выравниваниеToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // столбецыToolStripMenuItem
            // 
            this.столбецыToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.добавитьToolStripMenuItem,
            this.удалитьToolStripMenuItem,
            this.цветToolStripMenuItem,
            this.инфКToolStripMenuItem});
            this.столбецыToolStripMenuItem.Name = "столбецыToolStripMenuItem";
            this.столбецыToolStripMenuItem.Size = new System.Drawing.Size(69, 20);
            this.столбецыToolStripMenuItem.Text = "Столбцы";
            // 
            // добавитьToolStripMenuItem
            // 
            this.добавитьToolStripMenuItem.Name = "добавитьToolStripMenuItem";
            this.добавитьToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.добавитьToolStripMenuItem.Text = "Добавить";
            this.добавитьToolStripMenuItem.Click += new System.EventHandler(this.добавитьToolStripMenuItem_Click);
            // 
            // удалитьToolStripMenuItem
            // 
            this.удалитьToolStripMenuItem.Name = "удалитьToolStripMenuItem";
            this.удалитьToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.удалитьToolStripMenuItem.Text = "Удалить";
            this.удалитьToolStripMenuItem.Click += new System.EventHandler(this.удалитьToolStripMenuItem_Click);
            // 
            // цветToolStripMenuItem
            // 
            this.цветToolStripMenuItem.Name = "цветToolStripMenuItem";
            this.цветToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.цветToolStripMenuItem.Text = "цвет";
            this.цветToolStripMenuItem.Click += new System.EventHandler(this.цветToolStripMenuItem_Click);
            // 
            // строкиToolStripMenuItem
            // 
            this.строкиToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.добавитьToolStripMenuItem1,
            this.удалитьToolStripMenuItem1});
            this.строкиToolStripMenuItem.Name = "строкиToolStripMenuItem";
            this.строкиToolStripMenuItem.Size = new System.Drawing.Size(59, 20);
            this.строкиToolStripMenuItem.Text = "Строки";
            // 
            // добавитьToolStripMenuItem1
            // 
            this.добавитьToolStripMenuItem1.Name = "добавитьToolStripMenuItem1";
            this.добавитьToolStripMenuItem1.Size = new System.Drawing.Size(126, 22);
            this.добавитьToolStripMenuItem1.Text = "Добавить";
            this.добавитьToolStripMenuItem1.Click += new System.EventHandler(this.добавитьToolStripMenuItem1_Click);
            // 
            // удалитьToolStripMenuItem1
            // 
            this.удалитьToolStripMenuItem1.Name = "удалитьToolStripMenuItem1";
            this.удалитьToolStripMenuItem1.Size = new System.Drawing.Size(126, 22);
            this.удалитьToolStripMenuItem1.Text = "Удалить";
            this.удалитьToolStripMenuItem1.Click += new System.EventHandler(this.удалитьToolStripMenuItem1_Click);
            // 
            // задатьТекстВЗаголовкеToolStripMenuItem
            // 
            this.задатьТекстВЗаголовкеToolStripMenuItem.Name = "задатьТекстВЗаголовкеToolStripMenuItem";
            this.задатьТекстВЗаголовкеToolStripMenuItem.Size = new System.Drawing.Size(151, 20);
            this.задатьТекстВЗаголовкеToolStripMenuItem.Text = "задать текст в заголовке";
            this.задатьТекстВЗаголовкеToolStripMenuItem.Click += new System.EventHandler(this.задатьТекстВЗаголовкеToolStripMenuItem_Click);
            // 
            // выравниваниеЗаголовкаToolStripMenuItem
            // 
            this.выравниваниеЗаголовкаToolStripMenuItem.Name = "выравниваниеЗаголовкаToolStripMenuItem";
            this.выравниваниеЗаголовкаToolStripMenuItem.Size = new System.Drawing.Size(157, 20);
            this.выравниваниеЗаголовкаToolStripMenuItem.Text = "выравнивание заголовка";
            this.выравниваниеЗаголовкаToolStripMenuItem.Click += new System.EventHandler(this.выравниваниеЗаголовкаToolStripMenuItem_Click);
            // 
            // задатьШрифтВЗаголовкеToolStripMenuItem
            // 
            this.задатьШрифтВЗаголовкеToolStripMenuItem.Name = "задатьШрифтВЗаголовкеToolStripMenuItem";
            this.задатьШрифтВЗаголовкеToolStripMenuItem.Size = new System.Drawing.Size(162, 20);
            this.задатьШрифтВЗаголовкеToolStripMenuItem.Text = "задать шрифт в заголовке";
            this.задатьШрифтВЗаголовкеToolStripMenuItem.Click += new System.EventHandler(this.задатьШрифтВЗаголовкеToolStripMenuItem_Click);
            // 
            // размерToolStripMenuItem
            // 
            this.размерToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ширинаToolStripMenuItem});
            this.размерToolStripMenuItem.Name = "размерToolStripMenuItem";
            this.размерToolStripMenuItem.Size = new System.Drawing.Size(59, 20);
            this.размерToolStripMenuItem.Text = "размер";
            this.размерToolStripMenuItem.Click += new System.EventHandler(this.размерToolStripMenuItem_Click);
            // 
            // ширинаToolStripMenuItem
            // 
            this.ширинаToolStripMenuItem.Name = "ширинаToolStripMenuItem";
            this.ширинаToolStripMenuItem.Size = new System.Drawing.Size(119, 22);
            this.ширинаToolStripMenuItem.Text = "ширина";
            this.ширинаToolStripMenuItem.Click += new System.EventHandler(this.ширинаToolStripMenuItem_Click);
            // 
            // выравниваниеToolStripMenuItem
            // 
            this.выравниваниеToolStripMenuItem.Name = "выравниваниеToolStripMenuItem";
            this.выравниваниеToolStripMenuItem.Size = new System.Drawing.Size(99, 20);
            this.выравниваниеToolStripMenuItem.Text = "выравнивание";
            this.выравниваниеToolStripMenuItem.Click += new System.EventHandler(this.выравниваниеToolStripMenuItem_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 27);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 25;
            this.dataGridView1.Size = new System.Drawing.Size(776, 411);
            this.dataGridView1.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(426, 166);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 15);
            this.label1.TabIndex = 2;
            this.label1.Text = "label1";
            // 
            // инфКToolStripMenuItem
            // 
            this.инфКToolStripMenuItem.Name = "инфКToolStripMenuItem";
            this.инфКToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.инфКToolStripMenuItem.Text = "инф к";
            this.инфКToolStripMenuItem.Click += new System.EventHandler(this.инфКToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem столбецыToolStripMenuItem;
        private ToolStripMenuItem добавитьToolStripMenuItem;
        private ToolStripMenuItem удалитьToolStripMenuItem;
        private ToolStripMenuItem строкиToolStripMenuItem;
        private ToolStripMenuItem добавитьToolStripMenuItem1;
        private ToolStripMenuItem удалитьToolStripMenuItem1;
        private DataGridView dataGridView1;
        private ToolStripMenuItem задатьТекстВЗаголовкеToolStripMenuItem;
        private ToolStripMenuItem выравниваниеЗаголовкаToolStripMenuItem;
        private ToolStripMenuItem задатьШрифтВЗаголовкеToolStripMenuItem;
        private ToolStripMenuItem размерToolStripMenuItem;
        private ToolStripMenuItem ширинаToolStripMenuItem;
        private ToolStripMenuItem выравниваниеToolStripMenuItem;
        private ToolStripMenuItem цветToolStripMenuItem;
        private Label label1;
        private ToolStripMenuItem инфКToolStripMenuItem;
    }
}