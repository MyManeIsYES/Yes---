namespace _23пр11
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void добавитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dataGridView1.Columns.Add($"column-{dataGridView1.ColumnCount+1}",$"Header column-{dataGridView1.ColumnCount+1}");
        }

        private void добавитьToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Columns.Count > 0)
            {
                dataGridView1.Rows.Add();
            }
            else
            {
                MessageBox.Show("Строка не добавлина");
            }
            
        }

        private void удалитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int index=dataGridView1.Columns.Count-1;
            if (dataGridView1.Columns.Count>0 && index>=0 && index<dataGridView1.Columns.Count)
            {
                dataGridView1.Columns.RemoveAt(index);
            }
            else
            {
                MessageBox.Show("Столбец не удален");
            }
        }

        private void удалитьToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Columns.Count > 0 && dataGridView1.RowCount > 1)
            {
                dataGridView1.Rows.RemoveAt(0);
            }
            else
            {
                MessageBox.Show("Строка не удалена");
            }
        }

        private void задатьТекстВЗаголовкеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dataGridView1.ColumnCount > 0)
            {
                
                dataGridView1.Columns[0].HeaderText = "Header - 1";
                
            }
            else
            {
                MessageBox.Show("Текст не задан");
            }
        }

        private void выравниваниеЗаголовкаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dataGridView1.ColumnCount > 0)
            {
                

                dataGridView1.Columns[0].HeaderCell.Style.Alignment =
                DataGridViewContentAlignment.MiddleCenter;
            }
            else
            {
                MessageBox.Show("Выравнивание не выполнено");
            }
        }

        private void задатьШрифтВЗаголовкеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dataGridView1.ColumnCount > 0)
            {
                // установить шрифт заголовка
                dataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font("Arial", 12, FontStyle.Italic);
                dataGridView1.ColumnHeadersDefaultCellStyle.ForeColor = Color.Red;
                dataGridView1.Columns[0].DefaultCellStyle.Font= new Font("Arial", 14);
            }
            else
            {
                MessageBox.Show("Шрифт не задан");
                
            }
        }

        private void размерToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dataGridView1.Width = 600;
            dataGridView1.Height = 150;
        }

        private void ширинаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int nc;
            nc = dataGridView1.ColumnCount;
            if (nc > 0)
            {
                dataGridView1.Columns[0].Width = 70;
                dataGridView1.Rows[0].Height = 50;
            }
            else
            {
                MessageBox.Show("Ширина и высота столбца не задана"); 
            }
        }

        private void выравниваниеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int nc, nr;
            nc = dataGridView1.ColumnCount;
            nr = dataGridView1.RowCount;
            if ((nc > 0) && (nr > 1))
            {
                
                dataGridView1.RowsDefaultCellStyle.Alignment =
                DataGridViewContentAlignment.BottomRight;

                dataGridView1.Rows[0].DefaultCellStyle.Alignment =
                DataGridViewContentAlignment.MiddleCenter;

                dataGridView1.Columns[0].DefaultCellStyle.Alignment =
                DataGridViewContentAlignment.BottomLeft;
            }
        }

        private void цветToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int nc, nr;
            nc = dataGridView1.ColumnCount;
            nr = dataGridView1.RowCount;
            if ((nc > 0) && (nr > 1))
            {
                dataGridView1.Columns[0].DefaultCellStyle.BackColor = Color.Red;
                dataGridView1.Columns[0].DefaultCellStyle.ForeColor = Color.Blue;

                dataGridView1.Columns[0].DefaultCellStyle.Font = new Font("Times New Roman", 10, FontStyle.Bold);
            }
            else
            {
                MessageBox.Show("Шрифт не изменен"); 
            }
        }

        private void инфКToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int n;
            n = dataGridView1.Rows.Count;
            label1.Text = (n).ToString();
            n = dataGridView1.Columns.Count;
            label1.Text += n.ToString();
            int w;
            int nr, nc;
            nc = dataGridView1.Columns.Count;
            if (nc > 0)
            {
                w = dataGridView1.Columns[0].Width;
                label1.Text += w.ToString();
            }
            int h;
            
            nc = dataGridView1.Columns.Count;
            nr = dataGridView1.RowCount;
            if ((nr > 1) && (nc > 0))
            {
                h = dataGridView1.Rows[0].Height;
                label1.Text += h.ToString();
            }
        }
    }
}