﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _23пр5ПТПМ
{
	public partial class Form1 : Form
	{
        int x=100,y=40,ix=5,iy=5,h=10;
        
		Graphics g;
		Pen blackPen=new Pen(Color.Black, 3);
		Pen redPen=new Pen(Color.Red, 3);
		Pen bluePen=new Pen(Color.Blue, 3);
		Pen greenPen=new Pen(Color.Green, 3);
        Pen chocolatePen = new Pen(Color.Chocolate, 100);
        public Form1()
		{
			InitializeComponent();
		}

		private void линияToolStripMenuItem_Click(object sender, EventArgs e)
		{
			Random r = new Random();
			g = this.CreateGraphics();
                g.DrawLine(greenPen, 0,27,100,200);
			g.Dispose();
        }

		private void прямоугольникToolStripMenuItem_Click(object sender, EventArgs e)
		{
            g = this.CreateGraphics();
            g.DrawRectangle(blackPen, 100, 100, 200, 200);
            g.Dispose();
        }

		private void окрыжностьToolStripMenuItem_Click(object sender, EventArgs e)
		{
            g = this.CreateGraphics();
			g.DrawEllipse(blackPen,100,100,200,200);
            g.Dispose();
        }

		private void триугольникToolStripMenuItem_Click(object sender, EventArgs e)
		{
            g = this.CreateGraphics();
            Point[] tt = { new Point(300, 200), new Point(250, 100), new Point(200, 200) };
            g.DrawPolygon(blackPen,tt);
            g.Dispose();
        }

		private void трапецияToolStripMenuItem_Click(object sender, EventArgs e)
		{
            g = this.CreateGraphics();
            Point[] tt = { new Point(100, 100), new Point(200, 100), new Point(225, 200) , new Point(50, 200) };
            g.DrawPolygon(blackPen, tt);
            g.Dispose();
        }

		private void шестиугольникToolStripMenuItem_Click(object sender, EventArgs e)
		{
			int x=100, y=100,a=50;
            g = this.CreateGraphics();
            Point[] tt = { new Point(x, y), new Point(x+a, y-a), new Point(x+a*2, y), new Point(x+a*2, y+a),new Point(x+a, y+a*2), new Point(x, y+a) };
            g.DrawPolygon(blackPen, tt);
            g.Dispose();
        }

		private void очиститьToolStripMenuItem_Click(object sender, EventArgs e)
		{
            g = this.CreateGraphics();
			g.Clear(Color.WhiteSmoke);
            g.Dispose();
        }
		//
		private void кругToolStripMenuItem_Click(object sender, EventArgs e)
		{
            g = this.CreateGraphics();
			g.FillEllipse(Brushes.Beige, 100, 100, 200, 200);
            g.Dispose();
        }

		private void прямоугольникToolStripMenuItem1_Click(object sender, EventArgs e)
		{
            g = this.CreateGraphics();
            g.FillRectangle(Brushes.Tomato, 100, 100, 300, 200);
            g.Dispose();
        }

		private void квадратToolStripMenuItem_Click(object sender, EventArgs e)
		{
            g = this.CreateGraphics();
            g.FillRectangle(Brushes.Tan, 100, 100, 200, 200);
            g.Dispose();
        }

		private void овалToolStripMenuItem_Click(object sender, EventArgs e)
		{
            g = this.CreateGraphics();
            g.FillEllipse(Brushes.Beige, 10, 100, 300, 200);
            g.Dispose();
        }
		//
		private void задание30ToolStripMenuItem_Click(object sender, EventArgs e)
		{
			Color[] color = {Color.Red,Color.Aqua,Color.Blue,Color.Crimson,Color.BurlyWood };
            g = this.CreateGraphics();
            for (int i=1;i<=5;i++)
			{
				int a = 10;
				g.DrawRectangle(new Pen(color[i-1], 3), 100 + a * i, 100 + a * i, 200 - a*2 * i, 200 - a*2 * i);
			}
            g.Dispose();
        }
		//
		private void задание1ToolStripMenuItem_Click(object sender, EventArgs e)
		{
			Point[] mas={ new Point(120, 125), new Point(130, 125), new Point(100, 130) };
			Point[] mas2 = { new Point(250, 100), new Point(200, 150), new Point(300, 150) };
            Point[] mas3 = { new Point(250, 100+50-10), new Point(200, 150 + 50-10), new Point(300, 150 + 50-10) };
            Point[] mas4 = { new Point(250, 100+100-20), new Point(200, 150 + 100-20), new Point(300, 150 + 100-20) };
            g = this.CreateGraphics();
			g.FillEllipse(Brushes.White, 100, 100, 50, 50);
            g.FillEllipse(Brushes.White, 95, 140, 60, 60);
            g.FillEllipse(Brushes.White, 90, 190, 70, 70);
            g.FillEllipse(Brushes.Black, 110, 110, 10, 10);
            g.FillEllipse(Brushes.Black, 130, 110, 10, 10);
            g.FillPolygon(Brushes.Chocolate, mas);
			g.FillPolygon(Brushes.DarkGreen, mas2);
            g.FillPolygon(Brushes.DarkGreen, mas3);
            g.FillPolygon(Brushes.DarkGreen, mas4);
            g.Dispose();
        }

        

        //
        private void задание2ToolStripMenuItem_Click(object sender, EventArgs e)
		{
            timer1.Start();
            button1.Visible = true;
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            Graphics g = this.CreateGraphics();
         
            if (x <= 0||x >= this.Width-h-20)
                ix *= -1;
            if (y <= 27|| y >= this.Height-h-45)
                iy *= -1;
            x += ix;
            y += iy;

               g.DrawEllipse(new Pen(Color.Black, 3), x, y, h, h);
            Thread.Sleep(1);
            g.Clear(Color.WhiteSmoke);
            g.Dispose();
        }

        

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Stop();
            button1.Visible = false;
            penbool1 = false;
            timer2.Stop();
        }
        //
        private void задание3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        

        private void yx3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            g = this.CreateGraphics();
            g.Clear(Color.WhiteSmoke);
            float x0, y0, x1, y1, x2, y2;
            
            g.Clear(Color.WhiteSmoke);

            g.DrawLine(Pens.Black, this.Width / 2, 0, this.Width / 2, this.Height);
            g.DrawLine(Pens.Black, 0, this.Height / 2, this.Width, this.Height / 2);

            x0 = this.Width / 2;
            y0 = this.Height / 2;

            x1 = -100;
            y1 = (x1/10) * (x1/10) * (x1/10);

            for (int i = -99; i < 100; i++)
            {
                    x2 = i;
                    y2 = (x2/10)* (x2 / 10) * (x2 / 10);
                    g.DrawLine(new Pen(Color.BlueViolet),
                        (x1 + x0),
                        (-y1 + y0),
                        (x2 + x0),
                        (-y2 + y0));
                    x1 = x2;
                    y1 = y2;
            }

            g.Dispose();
        }

        

        private void yx2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            g = this.CreateGraphics();
            g.Clear(Color.WhiteSmoke);
            float x0, y0, x1, y1, x2, y2;

            g.Clear(Color.WhiteSmoke);

            g.DrawLine(Pens.Black, this.Width / 2, 0, this.Width / 2, this.Height);
            g.DrawLine(Pens.Black, 0, this.Height / 2, this.Width, this.Height / 2);

            x0 = this.Width / 2;
            y0 = this.Height / 2;

            x1 = -1000;
            y1 = (x1/10) * (x1/10);

            for (int i = -999; i < 1000; i++)
            {
                x2 = i;
                y2 = (x2/10) * (x2 / 10);

                g.DrawLine(new Pen(Color.BlueViolet), (x1 + x0), (-y1 + y0), (x2 + x0), (-y2 + y0));

                x1 = x2;
                y1 = y2;
            }

            g.Dispose();
        }

        

        

        //
        private void ysinxToolStripMenuItem_Click(object sender, EventArgs e)
        {
            g = this.CreateGraphics();
            g.Clear(Color.WhiteSmoke);
            float x0, y0, x1, y1, x2, y2;

            g.Clear(Color.WhiteSmoke);

            g.DrawLine(Pens.Black, this.Width / 2, 0, this.Width / 2, this.Height);
            g.DrawLine(Pens.Black, 0, this.Height / 2, this.Width, this.Height / 2);

            x0 = this.Width / 2;
            y0 = this.Height / 2;

            x1 = -1000;
            y1 = Convert.ToSingle(Math.Sin(Convert.ToDouble(x1/10)))*50;

            for (int i = -999; i < 1000; i++)
            {
                x2 = i;
                y2 = Convert.ToSingle(Math.Sin(Convert.ToDouble(x2/10)))*50;

                g.DrawLine(new Pen(Color.BlueViolet), (x1 + x0), (-y1 + y0), (x2 + x0), (-y2 + y0));

                x1 = x2;
                y1 = y2;
            }

            g.Dispose();
        }

        private void ycosxToolStripMenuItem_Click(object sender, EventArgs e)
        {
            g = this.CreateGraphics();
            g.Clear(Color.WhiteSmoke);
            float x0, y0, x1, y1, x2, y2;

            g.Clear(Color.WhiteSmoke);

            g.DrawLine(Pens.Black, this.Width / 2, 0, this.Width / 2, this.Height);
            g.DrawLine(Pens.Black, 0, this.Height / 2, this.Width, this.Height / 2);

            x0 = this.Width / 2;
            y0 = this.Height / 2;

            x1 = -1000;
            y1 = Convert.ToSingle(Math.Cos(Convert.ToDouble(x1 / 10))) * 50;

            for (int i = -999; i < 1000; i++)
            {
                x2 = i;
                y2 = Convert.ToSingle(Math.Cos(Convert.ToDouble(x2 / 10))) * 50;

                g.DrawLine(new Pen(Color.BlueViolet), (x1 + x0), (-y1 + y0), (x2 + x0), (-y2 + y0));

                x1 = x2;
                y1 = y2;
            }

            g.Dispose();
        }
        //
        bool penbool1 = false;
        int mx1=0,my1=0,mx2=0,my2=0;

        

        private void задание5ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            penbool1 = true;
            button1.Visible = true;
        }
        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            if (penbool1 && e.Button==MouseButtons.Left)
            {
                g = this.CreateGraphics();
                my2 = my1;
                mx2 = mx1;
                mx1 = e.X;
                my1 = e.Y;
                g.DrawLine(Pens.Black, mx1, my1, mx2, my2);
                
                g.Dispose();
            }

        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            if (penbool1)
            {
                mx1 = e.X;
                my1 = e.Y;
            }
        }
        //
        Random rc = new Random();
        private void задание6ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            xc1 = 200; 
            yc1 = 0; 
            gc = 5; 
            vcv = 10; 
            vcp = 0;
            button1.Visible = true;
            timer2.Start();
            
        }
        int xc1 = 0, yc1 = 0, gc = 0, vcv = 0, vcp = 0;
        const int ppp=50;
        int[] masxc1 = new int[ppp];
        int[] masyc1 = new int[ppp];
        int[] masvcp = new int[ppp];
        private void timer2_Tick(object sender, EventArgs e)
        {
            g = this.CreateGraphics();
            g.Clear(Color.Gray);
            for (int i=0; i<masyc1.Length-1;i++)
            {
                if (masyc1[i] >= Height && rc.Next(0,5)==1)
                {
                    masyc1[i] = 0;
                    masxc1[i] = rc.Next(-200,700);
                    masvcp[i] = vcp;
                }
            }
            int[] masxc2 = new int[ppp];
            int[] masyc2 = new int[ppp];
            for (int i = 0; i < masyc2.Length - 1; i++)
            {
                masxc2[i] = masxc1[i] + vcv;
                masyc2[i] = masyc1[i] + 10 + masvcp[i];
                g.DrawLine(new Pen(Color.Aqua, 3), masxc1[i], masyc1[i], masxc2[i], masyc2[i]);
                masyc1[i] = masyc2[i];
                masxc1[i] = masxc2[i];
                masvcp[i] += gc;

            }


            /*int xc2 = xc1+vcv, yc2 = yc1+10+vcp;
            g.DrawLine(new Pen(Color.Black, 3),xc1, yc1, xc2, yc2);
            yc1 =yc2;
            xc1 = xc2;
            vcp += gc;*/
            g.Dispose();
        }
        //
        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
