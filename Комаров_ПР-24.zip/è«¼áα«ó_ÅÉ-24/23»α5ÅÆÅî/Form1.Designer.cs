﻿namespace _23пр5ПТПМ
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.фигураToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.линияToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.прямоугольникToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.окрыжностьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.триугольникToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.трапецияToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.шестиугольникToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.очиститьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.заданияToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.заданиеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.кругToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.прямоугольникToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.квадратToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.овалToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.задание30ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.задание1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.задание2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.задание3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.yx3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.yx2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.задание4ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ysinxToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ycosxToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.задание5ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.button1 = new System.Windows.Forms.Button();
            this.задание6ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.фигураToolStripMenuItem,
            this.заданияToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // фигураToolStripMenuItem
            // 
            this.фигураToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.линияToolStripMenuItem,
            this.прямоугольникToolStripMenuItem,
            this.окрыжностьToolStripMenuItem,
            this.триугольникToolStripMenuItem,
            this.трапецияToolStripMenuItem,
            this.шестиугольникToolStripMenuItem,
            this.очиститьToolStripMenuItem});
            this.фигураToolStripMenuItem.Name = "фигураToolStripMenuItem";
            this.фигураToolStripMenuItem.Size = new System.Drawing.Size(59, 20);
            this.фигураToolStripMenuItem.Text = "фигура";
            // 
            // линияToolStripMenuItem
            // 
            this.линияToolStripMenuItem.Name = "линияToolStripMenuItem";
            this.линияToolStripMenuItem.Size = new System.Drawing.Size(161, 22);
            this.линияToolStripMenuItem.Text = "линия";
            this.линияToolStripMenuItem.Click += new System.EventHandler(this.линияToolStripMenuItem_Click);
            // 
            // прямоугольникToolStripMenuItem
            // 
            this.прямоугольникToolStripMenuItem.Name = "прямоугольникToolStripMenuItem";
            this.прямоугольникToolStripMenuItem.Size = new System.Drawing.Size(161, 22);
            this.прямоугольникToolStripMenuItem.Text = "прямоугольник";
            this.прямоугольникToolStripMenuItem.Click += new System.EventHandler(this.прямоугольникToolStripMenuItem_Click);
            // 
            // окрыжностьToolStripMenuItem
            // 
            this.окрыжностьToolStripMenuItem.Name = "окрыжностьToolStripMenuItem";
            this.окрыжностьToolStripMenuItem.Size = new System.Drawing.Size(161, 22);
            this.окрыжностьToolStripMenuItem.Text = "окрыжность";
            this.окрыжностьToolStripMenuItem.Click += new System.EventHandler(this.окрыжностьToolStripMenuItem_Click);
            // 
            // триугольникToolStripMenuItem
            // 
            this.триугольникToolStripMenuItem.Name = "триугольникToolStripMenuItem";
            this.триугольникToolStripMenuItem.Size = new System.Drawing.Size(161, 22);
            this.триугольникToolStripMenuItem.Text = "триугольник";
            this.триугольникToolStripMenuItem.Click += new System.EventHandler(this.триугольникToolStripMenuItem_Click);
            // 
            // трапецияToolStripMenuItem
            // 
            this.трапецияToolStripMenuItem.Name = "трапецияToolStripMenuItem";
            this.трапецияToolStripMenuItem.Size = new System.Drawing.Size(161, 22);
            this.трапецияToolStripMenuItem.Text = "трапеция";
            this.трапецияToolStripMenuItem.Click += new System.EventHandler(this.трапецияToolStripMenuItem_Click);
            // 
            // шестиугольникToolStripMenuItem
            // 
            this.шестиугольникToolStripMenuItem.Name = "шестиугольникToolStripMenuItem";
            this.шестиугольникToolStripMenuItem.Size = new System.Drawing.Size(161, 22);
            this.шестиугольникToolStripMenuItem.Text = "шестиугольник";
            this.шестиугольникToolStripMenuItem.Click += new System.EventHandler(this.шестиугольникToolStripMenuItem_Click);
            // 
            // очиститьToolStripMenuItem
            // 
            this.очиститьToolStripMenuItem.Name = "очиститьToolStripMenuItem";
            this.очиститьToolStripMenuItem.Size = new System.Drawing.Size(161, 22);
            this.очиститьToolStripMenuItem.Text = "очистить";
            this.очиститьToolStripMenuItem.Click += new System.EventHandler(this.очиститьToolStripMenuItem_Click);
            // 
            // заданияToolStripMenuItem
            // 
            this.заданияToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.заданиеToolStripMenuItem,
            this.задание30ToolStripMenuItem,
            this.задание1ToolStripMenuItem,
            this.задание2ToolStripMenuItem,
            this.задание3ToolStripMenuItem,
            this.задание4ToolStripMenuItem,
            this.задание5ToolStripMenuItem,
            this.задание6ToolStripMenuItem});
            this.заданияToolStripMenuItem.Name = "заданияToolStripMenuItem";
            this.заданияToolStripMenuItem.Size = new System.Drawing.Size(62, 20);
            this.заданияToolStripMenuItem.Text = "задания";
            // 
            // заданиеToolStripMenuItem
            // 
            this.заданиеToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.кругToolStripMenuItem,
            this.прямоугольникToolStripMenuItem1,
            this.квадратToolStripMenuItem,
            this.овалToolStripMenuItem});
            this.заданиеToolStripMenuItem.Name = "заданиеToolStripMenuItem";
            this.заданиеToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.заданиеToolStripMenuItem.Text = "задание 0.2";
            // 
            // кругToolStripMenuItem
            // 
            this.кругToolStripMenuItem.Name = "кругToolStripMenuItem";
            this.кругToolStripMenuItem.Size = new System.Drawing.Size(161, 22);
            this.кругToolStripMenuItem.Text = "круг";
            this.кругToolStripMenuItem.Click += new System.EventHandler(this.кругToolStripMenuItem_Click);
            // 
            // прямоугольникToolStripMenuItem1
            // 
            this.прямоугольникToolStripMenuItem1.Name = "прямоугольникToolStripMenuItem1";
            this.прямоугольникToolStripMenuItem1.Size = new System.Drawing.Size(161, 22);
            this.прямоугольникToolStripMenuItem1.Text = "прямоугольник";
            this.прямоугольникToolStripMenuItem1.Click += new System.EventHandler(this.прямоугольникToolStripMenuItem1_Click);
            // 
            // квадратToolStripMenuItem
            // 
            this.квадратToolStripMenuItem.Name = "квадратToolStripMenuItem";
            this.квадратToolStripMenuItem.Size = new System.Drawing.Size(161, 22);
            this.квадратToolStripMenuItem.Text = "квадрат";
            this.квадратToolStripMenuItem.Click += new System.EventHandler(this.квадратToolStripMenuItem_Click);
            // 
            // овалToolStripMenuItem
            // 
            this.овалToolStripMenuItem.Name = "овалToolStripMenuItem";
            this.овалToolStripMenuItem.Size = new System.Drawing.Size(161, 22);
            this.овалToolStripMenuItem.Text = "овал";
            this.овалToolStripMenuItem.Click += new System.EventHandler(this.овалToolStripMenuItem_Click);
            // 
            // задание30ToolStripMenuItem
            // 
            this.задание30ToolStripMenuItem.Name = "задание30ToolStripMenuItem";
            this.задание30ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.задание30ToolStripMenuItem.Text = "задание 0.3";
            this.задание30ToolStripMenuItem.Click += new System.EventHandler(this.задание30ToolStripMenuItem_Click);
            // 
            // задание1ToolStripMenuItem
            // 
            this.задание1ToolStripMenuItem.Name = "задание1ToolStripMenuItem";
            this.задание1ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.задание1ToolStripMenuItem.Text = "задание 1";
            this.задание1ToolStripMenuItem.Click += new System.EventHandler(this.задание1ToolStripMenuItem_Click);
            // 
            // задание2ToolStripMenuItem
            // 
            this.задание2ToolStripMenuItem.Name = "задание2ToolStripMenuItem";
            this.задание2ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.задание2ToolStripMenuItem.Text = "задание 2";
            this.задание2ToolStripMenuItem.Click += new System.EventHandler(this.задание2ToolStripMenuItem_Click);
            // 
            // задание3ToolStripMenuItem
            // 
            this.задание3ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.yx3ToolStripMenuItem,
            this.yx2ToolStripMenuItem});
            this.задание3ToolStripMenuItem.Name = "задание3ToolStripMenuItem";
            this.задание3ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.задание3ToolStripMenuItem.Text = "задание 3";
            this.задание3ToolStripMenuItem.Click += new System.EventHandler(this.задание3ToolStripMenuItem_Click);
            // 
            // yx3ToolStripMenuItem
            // 
            this.yx3ToolStripMenuItem.Name = "yx3ToolStripMenuItem";
            this.yx3ToolStripMenuItem.Size = new System.Drawing.Size(108, 22);
            this.yx3ToolStripMenuItem.Text = "y=x^3";
            this.yx3ToolStripMenuItem.Click += new System.EventHandler(this.yx3ToolStripMenuItem_Click);
            // 
            // yx2ToolStripMenuItem
            // 
            this.yx2ToolStripMenuItem.Name = "yx2ToolStripMenuItem";
            this.yx2ToolStripMenuItem.Size = new System.Drawing.Size(108, 22);
            this.yx2ToolStripMenuItem.Text = "y=x^2";
            this.yx2ToolStripMenuItem.Click += new System.EventHandler(this.yx2ToolStripMenuItem_Click);
            // 
            // задание4ToolStripMenuItem
            // 
            this.задание4ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ysinxToolStripMenuItem,
            this.ycosxToolStripMenuItem});
            this.задание4ToolStripMenuItem.Name = "задание4ToolStripMenuItem";
            this.задание4ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.задание4ToolStripMenuItem.Text = "задание 4";
            // 
            // ysinxToolStripMenuItem
            // 
            this.ysinxToolStripMenuItem.Name = "ysinxToolStripMenuItem";
            this.ysinxToolStripMenuItem.Size = new System.Drawing.Size(120, 22);
            this.ysinxToolStripMenuItem.Text = "y=sin(x)";
            this.ysinxToolStripMenuItem.Click += new System.EventHandler(this.ysinxToolStripMenuItem_Click);
            // 
            // ycosxToolStripMenuItem
            // 
            this.ycosxToolStripMenuItem.Name = "ycosxToolStripMenuItem";
            this.ycosxToolStripMenuItem.Size = new System.Drawing.Size(120, 22);
            this.ycosxToolStripMenuItem.Text = "y=cos(x)";
            this.ycosxToolStripMenuItem.Click += new System.EventHandler(this.ycosxToolStripMenuItem_Click);
            // 
            // задание5ToolStripMenuItem
            // 
            this.задание5ToolStripMenuItem.Name = "задание5ToolStripMenuItem";
            this.задание5ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.задание5ToolStripMenuItem.Text = "задание 5";
            this.задание5ToolStripMenuItem.Click += new System.EventHandler(this.задание5ToolStripMenuItem_Click);
            // 
            // timer1
            // 
            this.timer1.Interval = 1;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 27);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(44, 27);
            this.button1.TabIndex = 1;
            this.button1.Text = "stop";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // задание6ToolStripMenuItem
            // 
            this.задание6ToolStripMenuItem.Name = "задание6ToolStripMenuItem";
            this.задание6ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.задание6ToolStripMenuItem.Text = "задание 6";
            this.задание6ToolStripMenuItem.Click += new System.EventHandler(this.задание6ToolStripMenuItem_Click);
            // 
            // timer2
            // 
            this.timer2.Interval = 50;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 609);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseMove);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem фигураToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem линияToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem прямоугольникToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem окрыжностьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem триугольникToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem трапецияToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem шестиугольникToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem очиститьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem заданияToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem заданиеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem кругToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem прямоугольникToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem квадратToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem овалToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem задание30ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem задание1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem задание2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem задание3ToolStripMenuItem;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ToolStripMenuItem yx3ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem yx2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem задание4ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ysinxToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ycosxToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem задание5ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem задание6ToolStripMenuItem;
        private System.Windows.Forms.Timer timer2;
    }
}

